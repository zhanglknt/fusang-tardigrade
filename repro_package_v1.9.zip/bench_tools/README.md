# External Tools — 下载和安装指南

以下工具有 **不受此包管理的外部依赖**（二进制程序），需要手动下载安装。

---

## 工具总览

| # | 工具 | 版本 | 下载地址 | 用途 | 必须？ |
|---|------|------|----------|------|--------|
| T1 | MAFFT | v7.505+ | https://mafft.cbrc.jp/alignment/software/ | 多序列比对 | 可选（L3 MSA） |
| T2 | FastTree2 | v2.1.11+ | http://www.microbesonline.org/fasttree/ | ML 建树 | 可选（L3 ML） |
| T3 | FastME | v2.1.6+ | http://www.atgc-montpellier.fr/fastme/ | BME/NJ 加速 | 可选 |
| T4 | IQ-TREE2 | v2.2.0+ | http://www.iqtree.org/ | 金标准 ML | 可选（IQ-TREE 对比） |
| T5 | INDELible | v1.03+ | http://abacus.gene.ucl.ac.uk/software/indelible/ | Indel 序列生成 | 可选（indel benchmark） |

---

## 按 OS 安装

### Linux (Ubuntu/Debian)

```bash
# === MAFFT ===
sudo apt-get update
sudo apt-get install -y mafft

# === FastTree2 ===
sudo apt-get install -y fasttree

# === IQ-TREE2 ===
sudo apt-get install -y iqtree2

# === FastME (手动下载) ===
mkdir -p /tmp/fastme && cd /tmp/fastme
wget http://www.atgc-montpellier.fr/download/sources/fastme/fastme-2.1.6.4-linux64.tar.gz
tar xzf fastme-2.1.6.4-linux64.tar.gz
cd fastme-2.1.6.4-linux64/binaries/
sudo cp fastme-2.1.6.4-linux64-64bit /usr/local/bin/fastme
sudo chmod +x /usr/local/bin/fastme

# === INDELible (手动编译) ===
mkdir -p /tmp/indelible && cd /tmp/indelible
wget http://abacus.gene.ucl.ac.uk/software/INDELibleV1.03.tar.gz
tar xzf INDELibleV1.03.tar.gz
cd INDELibleV1.03
make
sudo cp indelible /usr/local/bin/

# 验证
mafft --version
fasttree 2>&1 | head -1
iqtree2 --version
fastme --version
```

### macOS

```bash
# === MAFFT ===
brew install mafft

# === FastTree2 ===
brew install fasttree

# === IQ-TREE2 ===
brew install iqtree2

# === FastME ===
brew install fastme

# 验证
mafft --version
fasttree 2>&1 | head -1
iqtree2 --version
fastme --version
```

### Windows

| 工具 | 下载页面 | 安装方式 |
|------|----------|----------|
| **MAFFT** | https://mafft.cbrc.jp/alignment/software/windows.html | 下载 `.zip`，解压到 `C:\Program Files\MAFFT\`，使用 `mafft.bat` |
| **FastTree2** | http://www.microbesonline.org/fasttree/#Install | 下载 `FastTree.exe`，放到 `bench_tools/` 或 PATH 中 |
| **IQ-TREE2** | http://www.iqtree.org/#download | 下载 Windows 预编译版，解压，将 `bin/` 加入 PATH |
| **INDELible** | http://abacus.gene.ucl.ac.uk/software/indelible/ | ❌ 无 Windows 二进制 → **需 WSL 编译**（见下文） |

**INDELible on Windows (WSL)**:
```bash
# 在 WSL (Ubuntu) 中:
cd /tmp
wget http://abacus.gene.ucl.ac.uk/software/INDELibleV1.03.tar.gz
tar xzf INDELibleV1.03.tar.gz
cd INDELibleV1.03 && make
sudo cp indelible /usr/local/bin/
```

---

## 环境变量配置

如果工具安装在非标准路径，设置以下环境变量让 Python 脚本找到它们：

```bash
# Linux/macOS:
export MAFFT="/usr/local/bin/mafft"
export FASTTREE="/usr/local/bin/fasttree"
export FASTTREE_EXE="/usr/local/bin/FastTree"         # 注意大小写
export FASTME="/usr/local/bin/fastme"
export IQTREE="/usr/local/bin/iqtree2"

# Windows (Git Bash):
export MAFFT="/c/Program Files/MAFFT/mafft.bat"
export FASTTREE="/c/Program Files/FastTree/FastTree.exe"
export FASTTREE_EXE="/c/Program Files/FastTree/FastTree.exe"
export IQTREE="/c/Program Files/IQ-TREE2/bin/iqtree2.exe"
```

---

## 验证安装

将工具放在 `bench_tools/` 目录下并验证：

```bash
# 进入 tools 目录（可选）
cd repro_package/bench_tools/

# 测试每个工具
mafft --version      2>/dev/null    && echo "[OK] MAFFT"       || echo "[MISSING] MAFFT — 需要安装"
FastTree             2>/dev/null    && echo "[OK] FastTree2"   || echo "[MISSING] FastTree2 — 需要安装"
fastme --version     2>/dev/null    && echo "[OK] FastME"      || echo "[MISSING] FastME — 可选"
iqtree2 --version    2>/dev/null    && echo "[OK] IQ-TREE2"    || echo "[MISSING] IQ-TREE2 — 可选"
indelible --version  2>/dev/null    && echo "[OK] INDELible"   || echo "[MISSING] INDELible — 可选"
```
