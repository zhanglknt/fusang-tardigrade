"""
MinHash-LSH pre-filtering wrapper for Fusang.
Demonstrates scaling to 50K+ taxa by avoiding the full n x n distance matrix.

Usage:
    python fusang_minhash_wrapper.py --input taxa10000.fasta --output tree.nwk --group_size 500
"""

import sys, os, time, json
import numpy as np
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform

# --- MinHash core (self-contained, no external deps) ---

def seq_to_minhash_int(seq, k=5, num_hashes=128, seed=42):
    """
    Compute MinHash signature as a list of *integer* hash values.
    Each k-mer is converted to an integer (canonical form),
    then hashed *num_hashes* times via the hash-rotation trick.
    Returns: np.array(dtype=np.uint64, shape=(num_hashes,))
    """
    seq = seq.upper()
    n = len(seq)
    rng = __import__('random').Random(seed)
    hash_seeds = [rng.randint(1, 2**30) for _ in range(num_hashes)]
    sig = [2**64-1] * num_hashes  # uint64 max
    complement = {'A':'T','T':'A','C':'G','G':'C'}
    for i in range(n - k + 1):
        kmer = seq[i:i+k]
        # Canonical integer: min of forward and reverse complement
        val_fwd = 0
        val_rev = 0
        ok = True
        for j, c in enumerate(kmer):
            if c == 'A':
                val_fwd = (val_fwd << 2)
                val_rev = (val_rev << 2) | 3
            elif c == 'C':
                val_fwd = (val_fwd << 2) | 1
                val_rev = (val_rev << 2) | 2
            elif c == 'T':
                val_fwd = (val_fwd << 2) | 2
                val_rev = (val_rev << 2) | 0
            elif c == 'G':
                val_fwd = (val_fwd << 2) | 3
                val_rev = (val_rev << 2) | 1
            else:
                ok = False
                break
        if not ok:
            continue
        # Hash-rotation trick for multiple hash functions
        for hidx, hseed in enumerate(hash_seeds):
            h_fwd = (val_fwd * hseed) & 0xFFFFFFFFFFFFFFF
            h_rev = (val_rev * hseed) & 0xFFFFFFFFFFFFFFF
            h = min(h_fwd, h_rev)
            if h < sig[hidx]:
                sig[hidx] = h
    return np.array(sig, dtype=np.uint64)


def minhash_jaccard(s1, s2):
    """Estimate Jaccard similarity from two MinHash signatures."""
    return float(np.sum(s1 == s2)) / len(s1)


def minhash_distance(s1, s2):
    return 1.0 - minhash_jaccard(s1, s2)


# --- LSH bucketing ---

def lsh_buckets(signatures, num_bands=32, band_width=None):
    """
    LSH bucketing using the banding technique.
    Returns: dict  bucket_id -> set of indices
    """
    n = len(signatures)
    sig_len = len(signatures[0])
    if band_width is None:
        band_width = sig_len // num_bands
        num_bands = sig_len // band_width
    
    buckets = {}
    for idx in range(n):
        sig = signatures[idx]
        for b in range(num_bands):
            start = b * band_width
            end = min(start + band_width, sig_len)
            band = sig[start:end].tobytes()
            bucket_id = hash((b, band)) % (num_bands * 50)
            if bucket_id not in buckets:
                buckets[bucket_id] = set()
            buckets[bucket_id].add(idx)
    
    # Merge very small buckets into nearest neighbor
    result = []
    assigned = set()
    for bid, members in buckets.items():
        if len(members) >= 2:
            result.append(sorted(members))
            assigned.update(members)
    
    # Singletons
    for idx in range(n):
        if idx not in assigned:
            result.append([idx])
    
    return result


# --- FASTA I/O ---

def read_fasta(path):
    names, seqs = [], []
    cur_name, cur_seq = None, []
    with open(path, encoding='utf-8', errors='replace') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                if cur_name is not None:
                    names.append(cur_name)
                    seqs.append(''.join(cur_seq))
                cur_name = line[1:].split()[0]
                cur_seq = []
            else:
                cur_seq.append(line.upper())
    if cur_name is not None:
        names.append(cur_name)
        seqs.append(''.join(cur_seq))
    return names, seqs


def write_fasta(path, names, seqs):
    with open(path, 'w') as f:
        for nm, sq in zip(names, seqs):
            f.write(f'>{nm}\n')
            for i in range(0, len(sq), 80):
                f.write(sq[i:i+80] + '\n')


# --- Main pipeline ---

def run_minhash_pipeline(input_fa, output_nwk, group_size=500, k=5, num_hashes=128,
                       fusang_py=None, tree_method='fastme'):
    """
    Main pipeline:
    1. Read FASTA
    2. Compute MinHash sketches
    3. LSH bucketing for coarse clusters
    4. For each cluster: run Fusang (--simple mode)  
    5. Merge subtrees via centroid-based NJ
    """
    t0 = time.time()
    
    print('[MinHash] Step 1: reading FASTA...')
    names, seqs = read_fasta(input_fa)
    n = len(names)
    print(f'  Read {n} sequences')
    
    print('[MinHash] Step 2: computing MinHash sketches (k={k}, sig={num_hashes})...')
    t1 = time.time()
    signatures = []
    for i, seq in enumerate(seqs):
        sig = seq_to_minhash_int(seq, k=k, num_hashes=num_hashes)
        signatures.append(sig)
        if (i+1) % 2000 == 0:
            print(f'  Computed {i+1}/{n}...')
    t2 = time.time()
    print(f'  Done in {t2-t1:.1f}s')
    
    print('[MinHash] Step 3: LSH bucketing (target group_size={group_size})...')
    # Auto-tune num_bands based on n and group_size
    num_bands = max(8, min(128, int(np.log2(n / group_size) * 16)))
    band_width = max(2, num_hashes // num_bands)
    raw_groups = lsh_buckets(signatures, num_bands=num_bands, band_width=band_width)
    
    # Merge over-sized groups by splitting
    groups = []
    for g in raw_groups:
        if len(g) > group_size:
            while g:
                groups.append(g[:group_size])
                g = g[group_size:]
        else:
            groups.append(g)
    
    # Merge tiny groups
    min_gs = max(2, group_size // 10)
    final_groups = []
    tiny = []
    for g in groups:
        if len(g) < min_gs:
            tiny.extend(g)
        else:
            final_groups.append(g)
    if tiny and final_groups:
        # Attach tiny taxa to the largest group
        largest = max(final_groups, key=len)
        largest.extend(tiny)
    elif tiny:
        final_groups.append(tiny)
    
    print(f'  LSH groups: {len(final_groups)}, sizes: min={min(len(g) for g in final_groups)}, '
          f'max={max(len(g) for g in final_groups)}, mean={np.mean([len(g) for g in final_groups]):.0f}')
    
    # Step 4: run Fusang on each group
    print(f'[MinHash] Step 4: building subtree for each of {len(final_groups)} groups...')
    if fusang_py is None:
        fusang_py = os.path.join(os.path.dirname(__file__), 'fusang_v2.py')
    
    PY = sys.executable
    subtrees = []
    
    for gi, group in enumerate(final_groups):
        t3 = time.time()
        # Write temp FASTA for this group
        g_names = [names[i] for i in group]
        g_seqs = [seqs[i] for i in group]
        tmp_fa = f'tmp_minhash_g{gi}.fasta'
        write_fasta(tmp_fa, g_names, g_seqs)
        
        # Run Fusang --simple (direct NJ/FastME, no DCM)
        tmp_out = f'tmp_minhash_g{gi}.nwk'
        cmd = [PY, fusang_py,
               '--input', tmp_fa,
               '--output', tmp_out,
               '--mode', 'default',
               '--simple',
               '--tree_method', tree_method]
        import subprocess
        ret = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        
        if ret.returncode == 0 and os.path.exists(tmp_out):
            from Bio import Phylo
            tree = Phylo.read(tmp_out, 'newick')
            subtrees.append((tree, group))
            t4 = time.time()
            print(f'  Group {gi}: n={len(group)}, time={t4-t3:.1f}s, OK')
        else:
            print(f'  Group {gi}: FAILED (exit={ret.returncode})')
            if ret.stderr:
                print(f'    STDERR: {ret.stderr[:200]}')
        
        # Cleanup
        try:
            os.remove(tmp_fa)
            os.remove(tmp_out)
        except:
            pass
    
    # Step 5: merge subtrees
    print(f'[MinHash] Step 5: merging {len(subtrees)} subtrees...')
    if len(subtrees) == 1:
        final_tree = subtrees[0][0]
    elif len(subtrees) == 0:
        print('[ERROR] No subtrees produced!')
        sys.exit(1)
    else:
        # Build centroid-based backbone tree
        # For each subtree, compute centroid signature
        centroid_sigs = []
        for subtree, group in subtrees:
            # Centroid = taxon with median average distance to others in group
            g_sigs = [signatures[i] for i in group]
            # Approximate centroid: signature closest to the mean signature
            mean_sig = np.mean(np.array(g_sigs), axis=0).astype(np.uint64)
            best_idx = 0
            best_dist = float('inf')
            for j, s in enumerate(g_sigs):
                d = np.sum(s != mean_sig)  # Hamming distance of signatures
                if d < best_dist:
                    best_dist = d
                    best_idx = j
            centroid_sigs.append(g_sigs[best_idx])
        
        # Compute pairwise distances between centroids
        m = len(centroid_sigs)
        D_backbone = np.zeros((m, m))
        for i in range(m):
            for j in range(i+1, m):
                d = minhash_distance(centroid_sigs[i], centroid_sigs[j])
                D_backbone[i,j] = d
                D_backbone[j,i] = d
        
        # Build NJ tree on backbone
        from Bio import Phylo
        from io import StringIO
        # Simple NJ implementation for backbone
        # (use FastME if available, otherwise simple NJ)
        try:
            from fastme_backend import build_tree_fastme
            backbone_tree = build_tree_fastme(D_backbone)
            # Rename backbone leaves to REP_i
            for leaf in backbone_tree.get_terminals():
                idx = int(leaf.name)
                leaf.name = f'REP_{idx}'
        except ImportError:
            # Simple NJ for backbone (m is small, typically < 20)
            import scipy.cluster.hierarchy as sch
            condensed = squareform(D_backbone)
            Z = sch.linkage(condensed, method='average')
            root = Phylo.BaseTree.TreeElement()
            # Convert linkage to Bio.Phylo tree
            from Bio.Phylo import Nexus
            # Use scipy to Bio.Phylo conversion
            backbone_tree = Phylo.read(StringIO(sch.to_tree(Z).to_newick()), 'newick', format='newick')
        
        # Graft subtrees onto backbone
        final_tree = backbone_tree
        print(f'  Backbone: {m} representatives, grafting {m} subtrees...')
        # (Simplified: just attach subtrees as children of backbone leaves)
        # Full EPA grafting is complex; for demo, use a simple approach:
        # Replace each REP_i leaf with the corresponding subtree
        for leaf in list(final_tree.get_terminals()):
            rep_name = leaf.name
            if rep_name.startswith('REP_'):
                idx = int(rep_name.split('_')[1])
                subtree, _ = subtrees[idx]
                # Replace leaf with subtree root
                leaf.clade = subtree.root if hasattr(subtree, 'root') else subtree
        
        print(f'  Merged tree: {len(list(final_tree.get_terminals()))} leaves')
    
    # Write output
    from Bio import Phylo
    Phylo.write(final_tree, output_nwk, 'newick')
    elapsed = time.time() - t0
    print(f'\n[MinHash] Done! Total time: {elapsed:.1f}s')
    print(f'  Output: {output_nwk}')
    return final_tree


# --- CLI ---

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Fusang + MinHash LSH scalable wrapper')
    parser.add_argument('--input', '-i', required=True, help='Input FASTA')
    parser.add_argument('--output', '-o', required=True, help='Output Newick file')
    parser.add_argument('--group_size', type=int, default=500, help='Max taxa per LSH group (default 500)')
    parser.add_argument('--k', type=int, default=5, help='k-mer size for MinHash (default 5)')
    parser.add_argument('--num_hashes', type=int, default=128, help='MinHash signature size (default 128)')
    parser.add_argument('--fusang_py', type=str, default=None, help='Path to fusang_v2.py')
    parser.add_argument('--tree_method', type=str, default='fastme', choices=['nj', 'fastme'],
                        help='Tree method for subgroup trees (default fastme)')
    args = parser.parse_args()
    
    run_minhash_pipeline(
        input_fa=args.input,
        output_nwk=args.output,
        group_size=args.group_size,
        k=args.k,
        num_hashes=args.num_hashes,
        fusang_py=args.fusang_py,
        tree_method=args.tree_method
    )
