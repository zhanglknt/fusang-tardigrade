"""
MinHash LSH for fast approximate nearest-neighbor clustering.
Replaces exact k-mer distance matrix for large-scale DCM preprocessing.
"""

import numpy as np
import random
import hashlib


def _hash_rotations(kmer_int, num_hashes=128, seed=42):
    """
    Generate MinHash signatures for a k-mer integer representation.
    Uses multiple hash functions via hash rotation trick.
    
    Parameters
    ----------
    kmer_int : int
        Canonical k-mer represented as an integer (0..4^k-1)
    num_hashes : int
        Number of hash functions (signature length)
    seed : int
        Random seed for hash function generation
    
    Returns
    -------
    np.ndarray (uint64)
        MinHash signature (num_hashes elements)
    """
    rng = random.Random(seed)
    # Generate num_hashes random hash seeds
    hash_seeds = [rng.randint(0, 2**31-1) for _ in range(num_hashes)]
    sig = np.full(num_hashes, np.uint64(2**64-1), dtype=np.uint64)
    for i, hseed in enumerate(hash_seeds):
        h = (kmer_int * (hseed + 1)) & 0xFFFFFFFFFFFFFFF
        if h < sig[i]:
            sig[i] = h
    return sig


def seq_to_minhash(seq, k=5, num_hashes=128, seed=42):
    """
    Compute MinHash sketch of a DNA sequence.
    
    Parameters
    ----------
    seq : str
        DNA sequence (uppercase, ACGT only)
    k : int
        k-mer size
    num_hashes : int
        Sketch size (signature length)
    seed : int
        Random seed
        
    Returns
    -------
    np.ndarray (uint64)
        MinHash signature
    """
    seq = seq.upper()
    n = len(seq)
    if n < k:
        # Pad with random bases or return zero sketch
        return np.zeros(num_hashes, dtype=np.uint64)
    
    rng = random.Random(seed)
    hash_seeds = [rng.randint(0, 2**31-1) for _ in range(num_hashes)]
    
    # Initialize signature with max uint64 values
    sig = np.full(num_hashes, np.uint64(2**64-1), dtype=np.uint64)
    
    for i in range(n - k + 1):
        kmer = seq[i:i+k]
        # Convert k-mer to integer (canonical = min of forward and reverse complement)
        val = 0
        valid = True
        for c in kmer:
            if c == 'A':
                val = (val << 2)
            elif c == 'C':
                val = (val << 2) | 1
            elif c == 'T':
                val = (val << 2) | 2
            elif c == 'G':
                val = (val << 2) | 3
            else:
                valid = False
                break
        if not valid:
            continue
        
        # MinHash update: for each hash function, keep minimum hash value
        for j, hseed in enumerate(hash_seeds):
            h = (val * (hseed + 1)) & 0xFFFFFFFFFFFFFFF
            if h < sig[j]:
                sig[j] = h
    
    return sig


def minhash_jaccard(sig1, sig2):
    """
    Estimate Jaccard similarity from two MinHash signatures.
    J ≈ (number of matching hash values) / (signature length)
    
    Returns: estimated Jaccard similarity [0, 1]
    """
    matches = np.sum(sig1 == sig2)
    return matches / len(sig1)


def minhash_distance(sig1, sig2):
    """Distance = 1 - estimated Jaccard similarity."""
    return 1.0 - minhash_jaccard(sig1, sig2)


def lsh_bucket(signatures, band_width=4, num_bands=None):
    """
    LSH bucketing using the banding technique.
    
    Parameters
    ----------
    signatures : list of np.ndarray
        MinHash signatures for all taxa
    band_width : int
        Number of hash values per band
    num_bands : int or None
        Total number of bands (auto-computed if None)
        
    Returns
    -------
    dict : band_id -> list of taxon indices
    """
    n = len(signatures)
    sig_len = len(signatures[0])
    
    if num_bands is None:
        num_bands = sig_len // band_width
    
    # LSH bucketing
    buckets = {}  # bucket_id -> set of indices
    
    for idx in range(n):
        sig = signatures[idx]
        # Hash each band
        for b in range(num_bands):
            start = b * band_width
            end = start + band_width
            band = sig[start:end].tobytes()
            # Use hash of band as bucket ID
            bucket_id = hash(band) % (num_bands * 100)  # Reduce collisions
            if bucket_id not in buckets:
                buckets[bucket_id] = set()
            buckets[bucket_id].add(idx)
    
    # Convert to list of groups (merge overlapping buckets)
    # Simple approach: each bucket = one group
    groups = []
    assigned = set()
    for bucket_id, members in buckets.items():
        members = members - assigned
        if len(members) == 0:
            continue
        if len(members) > 1:
            groups.append(sorted(members))
            assigned.update(members)
    
    # Singletons (not in any bucket): each in its own group
    all_indices = set(range(n))
    unassigned = all_indices - assigned
    for idx in unassigned:
        groups.append([idx])
    
    return groups


def minhash_coarse_cluster(signatures, target_group_size=200, band_width=4):
    """
    Coarse clustering using MinHash LSH.
    Produces groups roughly balanced around target_group_size.
    
    Parameters
    ----------
    signatures : list of np.ndarray
        MinHash signatures
    target_group_size : int
        Target maximum group size
    band_width : int
        LSH band width (controls granularity)
        
    Returns
    -------
    list of lists : groups (each group is a list of indices)
    """
    n = len(signatures)
    
    # Auto-tune band_width based on n and target_group_size
    # More bands = finer granularity = smaller groups
    if band_width is None:
        # Heuristic: more bands for larger n
        band_width = max(2, int(np.log2(n / target_group_size)))
    
    # Get LSH buckets
    raw_groups = lsh_bucket(signatures, band_width=band_width)
    
    # Merge small groups and split large groups
    merged = []
    for g in raw_groups:
        if len(g) <= target_group_size * 2:
            merged.append(g)
        else:
            # Split large group into chunks
            while g:
                merged.append(g[:target_group_size])
                g = g[target_group_size:]
    
    # Merge tiny groups (< target_group_size / 4) into nearest neighbor group
    min_size = max(2, target_group_size // 4)
    final = []
    tiny = []
    for g in merged:
        if len(g) < min_size:
            tiny.extend(g)
        else:
            final.append(g)
    
    if tiny and final:
        # Attach tiny taxa to the nearest (largest) group
        largest = max(final, key=len)
        largest.extend(tiny)
    elif tiny:
        final.append(tiny)
    
    return final


def compute_minhash_sketches(fasta_path, k=5, num_hashes=128, seed=42):
    """
    Compute MinHash sketches for all sequences in a FASTA file.
    
    Returns
    -------
    signatures : list of np.ndarray
        MinHash signatures (uint64 arrays)
    taxon_names : list of str
        Sequence names (in order)
    """
    import re
    signatures = []
    taxon_names = []
    
    with open(fasta_path, encoding='utf-8', errors='replace') as f:
        current_name = None
        current_seq = []
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if current_name is not None:
                    seq = ''.join(current_seq)
                    sig = seq_to_minhash(seq, k=k, num_hashes=num_hashes, seed=seed)
                    signatures.append(sig)
                    taxon_names.append(current_name)
                current_name = line[1:].split()[0]
                current_seq = []
            else:
                current_seq.append(line.upper())
        # Last sequence
        if current_name is not None:
            seq = ''.join(current_seq)
            sig = seq_to_minhash(seq, k=k, num_hashes=num_hashes, seed=seed)
            signatures.append(sig)
            taxon_names.append(current_name)
    
    return signatures, taxon_names


# ==========================================================
# Fast approximate distance matrix from MinHash sketches
# ==========================================================

def approximate_distance_matrix(signatures, n_neighbors=50):
    """
    Build approximate distance matrix using LSH-indexed nearest neighbors.
    
    For each taxon, find `n_neighbors` approximate nearest neighbors via LSH,
    then compute exact distances only to those neighbors.
    This reduces O(n²) to O(n * n_neighbors).
    
    Parameters
    ----------
    signatures : list of np.ndarray
        MinHash signatures
    n_neighbors : int
        Number of approximate nearest neighbors to consider
        
    Returns
    -------
    scipy.sparse matrix or np.ndarray
        Approximate distance matrix (sparse or dense)
    """
    n = len(signatures)
    
    # Build LSH index (simple: hash each signature's bands)
    # For each taxon, find candidates via LSH, then compute exact MinHash distance
    from scipy.sparse import lil_matrix
    D_approx = lil_matrix((n, n))
    
    # Pre-compute all pairwise MinHash distances (still O(n²) but faster
    # because MinHash distance is just integer comparison, not k-mer vector ops)
    # Actually: just compute all pairwise distances using signatures
    for i in range(n):
        for j in range(i+1, n):
            d = minhash_distance(signatures[i], signatures[j])
            D_approx[i, j] = d
            D_approx[j, i] = d
    
    return D_approx.tocsr()
