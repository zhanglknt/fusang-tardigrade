# 真实数据基准 nRF 标准化重算报告（realdata-rf2）

日期：2026-10-22。仓库：`D:\系统发育树项目\Fusang\Fusang-main`。

## 0. 方法与工具验证

**口径**：标准无根 RF = 非平凡 split 集合对称差，nRF = RF / 2(n−3)，n = 共享叶数；同时保留 RF/(s₁+s₂)（分辨率敏感口径）备查。

**Oracle 实现** `rf_audit.py`（新文件，用 `C:\Python314\python.exe` 运行）：

1. DendroPy 5.0.8 `treecompare.symmetric_difference`（`rooting="force-unrooted"`，先剪枝到共享叶集）；
2. 独立的显式 canonical split 提取器（按"不含字典序最小叶的一侧"规范化，过滤 1<|s|<n−1）；
3. 每对树两路实现结果逐位断言一致（下文所有 `agree=True`）；
4. **rerooting 不变性检验**：对 16S Fusang vs FT2 随机重根 20 次，nRF 恒为 0.371429（不变）。

**对团队 canonical 实现 `nrf_standard.py` 的核验**：该文件今日 10:11 已被更新（trivial-split 过滤改为 `1 < |s| < n−1`）。在 95 个真实数据树对上与 DendroPy oracle 对比：**94/94 可解析树对完全一致**；唯一失败是 16S 分类学参考树（内部标签含空格的引号标签 `‘Candidatus Neoarthromitus'`，其 tokenizer 不支持，属解析器限制而非 RF 数学错误）。剩余限制：(a) 不解析带空格的引号标签；(b) 不剪枝到共享叶集（分母用 tree1 的叶数）——本审计所有基准叶集一致，无数值影响。

**重算树一致性验证**：所有"重跑管线"的基准（SwissTree、BAliBASE），用**原** `calc_nrf_simple.calc_nrf` 在重建树上复算，与原始 CSV/JSON 逐位吻合（SwissTree 66/66，BAliBASE 20/20）→ 新旧差值**纯粹来自度量口径切换**，不含管线漂移。

---

## 1. 16S rRNA（Table 9 / Fig S5 / Note S17）——**原实现已等于标准无根 RF，数值全部不变**

- **原实现**：`real_data/real_16S_monophyly.py` 的 `splits_of()`（canonical 规范化 + 正确的 trivial 过滤）。
- **判定**：等于标准无根 RF（DendroPy 逐位验证一致）。
- 重算（`real_data/real_16S_rf_standard.csv`，n=73，分母 2(n−3)=140）：

| 比较 | RF | nRF(2n−6) | nRF(s₁+s₂) | 稿件原值 |
|---|---:|---:|---:|---:|
| Fusang k5,gap2 vs taxonomy（真·NCBI 5 rank） | 58 | **0.4143** | 0.5472 | 0.414 / 0.547 ✓ |
| FastTree2(MAFFT) vs taxonomy | 48 | **0.3429** | 0.4528 | 0.343 / 0.453 ✓ |
| Fusang vs FastTree2(MAFFT) | 52 | **0.3714** | 0.3714 | 0.371 ✓ |
| IQ-TREE2(MAFFT) vs taxonomy | 48 | 0.3429 | 0.4528 | — |

单系性计数复验（split 判据，root 无关）：Fusang 3/7 phyla、10/14 orders；FT2 6/7、11/14 —— 与稿件一致。
附带发现：Fusang k=6,gap2 在此数据集反而更好（nRF=0.3857 < k5g2 的 0.4143），供参考。
**结论：16S 部分无需任何修改。**

## 2. SwissTree 蛋白质（Table 10，11 families）——**原实现有偏，已重算；核心主张维持且增强，但"spaced 优势"主张消失**

- **原实现**：`benchmark_swisstree_corrected.py` → `calc_nrf_simple.calc_nrf`（根位置敏感、计入 trivial split、补集相对子树而非全树）。
- **判定**：≠ 标准无根 RF。已用原参数（数据、距离函数、NJ）原样重跑并保存全部 66 棵树，`rf_audit.py` 重新打分。
- 重建树与原运行逐位一致（66/66 复现原值）。

| 方法 | 旧 mean±sd | **新 mean±sd** | 旧 Wins/11 | **新 Wins/11** |
|---|---|---|---:|---:|
| Fusang k5,gap2（实际种子 `11011`） | 0.244±0.113 | **0.329±0.148** | 5 | **8** |
| Fusang k4,gap1（实际种子 `1011`） | 0.239±0.118 | **0.354±0.158** | 5 | **3** |
| K-mer cosine k=5 | 0.244±0.110 | **0.343±0.156** | 2 | **5** |
| K-mer cosine k=4 | 0.256±0.122 | **0.346±0.169** | 1 | **3** |
| Co-phylog halfctx=5 | 0.433±0.076 | **0.786±0.148** | 3 | **1**（仅 ST012 四方并列） |
| Co-phylog halfctx=11 | 0.361±0.059 | **0.727±0.109** | 0 | **0** |

统计检验（配对 Wilcoxon，n=11；负差 = Fusang 更好）。**p 值在整数 RF 计数上计算**（正确口径：nRF 浮点会因舍入噪声破坏秩并列而使 p 漂移，见 `rf_verification_record.md` 第 5 节第 1 条）：

| 比较 | 旧 p | **新 p（整数 RF，规范值）** | 新 p（浮点 nRF，仅供对照） | **新 Cohen's d** |
|---|---:|---:|---:|---:|
| Fusang k4g1 vs Co-phylog h5 | 0.014 | **0.00195** | 0.00195 | −2.110 |
| Fusang k4g1 vs Co-phylog h11 | 0.006 | **0.000977** | 0.000977 | −3.104 |
| Fusang k5g2 vs Co-phylog h5 | — | **0.00195** | 0.00195 | −2.169 |
| Fusang k5g2 vs Co-phylog h11 | — | **0.000977** | 0.000977 | −3.311 |
| spaced k4g1 vs contiguous k4 | 0.0078（显著） | **0.797（不显著，方向反转）** | 0.766 | +0.24 |
| spaced k5g2 vs contiguous k5 | 1.0 | **0.156（不显著）** | 0.094 | −0.63 |

整数 RF 口径下 SwissTree 三条结论均不变：k-mer 优于 Co-phylog（p 不变）、spaced 优势消失（两种口径均不显著）。已核验 8 组配对比较（另含 k4g1 vs contiguous k5、k5g2 vs contiguous k4），**没有任何一组跨越 0.05 或 0.01 阈值**；但浮点口径的漂移幅度本身可相当大（例：k4g1 vs contiguous k5 由 0.607 → 0.373），佐证了"必须在整数 RF 上做检验"的必要性。明细见 `swisstree_rf_recomputed/swisstree_paired_tests_intRF.csv` 与 summary json 的 `stats_intRF` 段。

**结论变化**：
1. "k-mer 频率法优于 context-matching"：**维持并增强**——倍率从 1.5×（0.361/0.239）变为 **2.1–2.4×**（0.727/0.354 或 0.786/0.329），p 从 0.006/0.014 收紧到 0.001/0.002，|d| 从 1.1–1.3 升到 2.11–3.31。摘要与正文该主张只需改数值，方向不变。
2. **"Spaced k-mers 在蛋白数据显著更优"（正文 finding 2，p=0.0078、d=−1.00、8/11 更好）不成立**：标准口径下 k4g1(0.354) 反而略差于 contiguous k4(0.346)，p=0.797（整数 RF 口径）。该"spaced 优势"是旧度量的伪影。正文 finding 2 需删除或改写（k5g2 vs k5 p=0.094 也仅是边缘、不显著）。
3. Table 10 注中"Co-phylog halfctx=5 wins ST008/ST009/ST012"失效（新口径下三family均为 k-mer 法更好，ST012 四方并列）。
4. 附带发现（口径之外的既有问题）：Table 10 把两行 Fusang 标为 "k=4,gap1 (1010101)"、"k=5,gap2 (1001001001001)"，但基准实际用的 gap_pattern 是 `'1011'`（weight-3, span-4）和 `'11011'`（weight-4, span-5），与括号里写的种子不一致，需要修标签或修配置。

## 3. BAliBASE v3.0（20 families，S7 / Fig S6C）——**原实现有偏，已重算；"competitive"结论反转**

- **原实现**：`benchmark_balibase.py` → `calc_nrf_simple.calc_nrf`（Fusang k=5,gap2,fastme on .tfa vs FastTree2 on .xml 对齐）。
- **判定**：≠ 标准无根 RF。已原样重跑并保存 40 棵树；20/20 复现原值（树一致）。
- 数据说明：RV11 下 `BB11002.{xml,msf,tfa}` 在工作区已损坏（存储损坏事件的又一处；XML 损坏共 6 个文件）。已从仓库内原始包 `balibase/BAliBASE_R1-5.tar.gz` 恢复 `BB11002` 后重跑；其余 19 个 family 的磁盘文件与 tar 包逐字节一致。

| 统计 | 旧（calc_nrf_simple） | **新（标准无根 RF）** |
|---|---:|---:|
| mean | 0.527 | **0.826** |
| median | 0.445 | **0.982** |
| < 0.5 的比例 | 65% | **15%**（3/20：BB11003=0, BB11004=0, BB12002=0.333） |
| 最大值 | 2.0（BB11001，>1 已属不可能值） | 1.0 |

**结论反转**：标准口径下 Fusang 树与 FastTree2 树在 BAliBASE 蛋白家族上**几乎不共享任何 split**（多数 family RF = 2(n−3)，0–2 个共享 split）。稿件"competitive performance with 65% of families below nRF 0.5 (median 0.45)"（正文、摘要、Fig S6C）**不能维持**；需要改写为"与 MSA+ML 树近乎无一致拓扑"（合理机制：蛋白短序列 + k=5 → 20⁅⁅ 维稀疏频率向量信号极弱）。注意该基准是 Fusang-vs-FT2 一致性而非对参考树的准确度，改写时应保留这一属性说明。

## 4. AFproject 基因组 / 线粒体（Table 12 / S16 / S17 gene loci）——**原实现（ETE3 unrooted）已等于标准无根 RF，数值全部不变**

- **原实现**：`ete3_scoring.py` / `score_gene_dna.py` → ETE3 `Tree.compare(unrooted=True)`，norm_rf，max_rf=2(n−3)，仅非平凡 split。
- **判定**：等于标准无根 RF（全部逐位复现）。
- 验证结果（`afproject_rf_recomputed/afproject_rf_standard.csv`，141 对）：
  - fish_mito（n=25）：multik **0.0455**（RF=2/44）、MAFFT+FT2 0.0455、kmacs k=10 0.0455、Mash k=11 0.0455、Co-phylog h5 0.0455 —— 与 Table 12 全部一致。
  - ecoli_shigella（n=27）：k-mer cosine **0.50**、Mash k=21 **0.208**、kmacs k=3 0.542 —— 与稿件一致。
  - 13 线粒体基因座：逐基因 vs 参考 52/52 与旧值一致；Fusang-vs-FT2 一致性 multik mean=0.451（旧 0.451）、k5=0.546、k7=0.451、k9=0.437 —— 摘要中 0.451±0.127 维持（sd 旧值用 ddof=1，为 0.1265）。
**结论：Table 12 与 S16/S17 无需修改。**

---

### 关于配对检验输入精度（整数 RF）的说明

nRF 全部落在 k/2(n−3) 的整数网格上；把浮点 nRF 直接喂给 Wilcoxon 会因舍入噪声破坏秩并列而使 p 值漂移（详见 `rf_verification_record.md` 第 5 节第 1 条）。本报告的**全部**配对检验均已切换为在**整数 RF 计数**上执行 `scipy.stats.wilcoxon(paired, two-sided, zero_method='zsplit')`（scipy 1.17.1）。

- **SwissTree**：8 组配对比较已重算，无阈值跨越，结论不变（见上节）。
- **16S rRNA**：本基准**不存在**基于 RF 的配对 Wilcoxon（Table 9 的 p 值来自对 patristic 距离的 10,000 次置换检验，输入是连续距离、不在 k/2(n−3) 网格上），故不受该问题影响，无需重算。
- **BAliBASE / AFproject**：我这两部分仅给出描述统计（median、<0.5 比例、per-dataset 数值），未做配对检验，不受影响。

**若审稿人问"为什么用整数 RF 而不是 nRF 做检验"，可直接引用的实测论据**：nRF 落在 k/2(n−3) 网格上，名义相同的差值因各自舍入噪声（~1e−17）不再并列，中秩分配被破坏。本批 SwissTree 实测：spaced k4g1 vs contiguous **k5** 的 p 值由浮点口径的 0.607 变为整数口径的 0.373（相对漂移 39%）。这说明**网格粗细不能用来判断漂移是否可忽略**（同一组数据、同一分母 140，另一组 k5g2 vs contiguous k4 则 0.0625 → 0.0625 纹丝不动）——因此统一在整数 RF 上做检验是唯一稳妥做法，而不是"通常影响不大所以可不改"。

## 5. 结论汇总

| 基准 | 原 nRF 实现 | 是否标准无根 RF | 数值是否变化 | 结论是否变化 |
|---|---|---|---|---|
| 16S rRNA（Table 9 等） | real_16S_monophyly.py splits_of | **是** | 否 | 否 |
| SwissTree（Table 10） | calc_nrf_simple.calc_nrf | **否** | 全部变化 | k-mer>Co-phylog **增强**（2.1–2.4×, p≤0.002）；**spaced 优势主张失效** |
| BAliBASE（S7/Fig S6C） | calc_nrf_simple.calc_nrf | **否** | 全部变化 | **"competitive/65%<0.5" 反转为近乎零一致（median 0.98）** |
| AFproject 基因组（Table 12） | ETE3 compare unrooted | **是** | 否 | 否 |
| 13 线粒体基因座（S17） | ETE3 compare unrooted | **是** | 否 | 否 |

## 6. 产出文件索引

- `rf_audit.py` — 标准无根 RF oracle（DendroPy + 显式实现 + rerooting 不变性）
- `real_data/recompute_16s_rf.py`、`real_data/real_16S_rf_standard.csv`、`real_data/_taxref_true_5rank.nwk`
- `recompute_swisstree_rf.py`、`swisstree_rf_recomputed/`（`swisstree_rf_standard.csv`、`swisstree_rf_summary.json`、`trees/`×66、`run.log`）
- `recompute_balibase_rf.py`、`balibase_rf_recomputed/`（`balibase_rf_standard.csv`、`balibase_rf_summary.json`、`trees/`×40）
- `recompute_afproject_rf.py`、`afproject_rf_recomputed/`（`afproject_rf_standard.csv`、`afproject_rf_summary.json`）
- `balibase/_restore/` — 从原始 tar 包恢复的 BAliBASE 副本（BB11002 等损坏文件来源）

未修改任何手稿文件。所有重算均在 `C:\Python314\python.exe`（dendropy 5.0.8 / numpy / scipy）下完成。
