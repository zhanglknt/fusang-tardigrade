#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standard unrooted Robinson-Foulds audit toolkit.

Oracle: DendroPy 5.0.8 `treecompare.symmetric_difference` (read with
`rooting="force-unrooted"`, i.e. the standard root-independent non-trivial-split
RF).  A second, independent split extractor (explicit canonicalisation by
reference leaf) is computed alongside and asserted equal; if they ever disagree
the result is flagged, never silently accepted.

Definitions
-----------
RF       = |S1 \\ S2| + |S2 \\ S1| over NON-TRIVIAL unrooted split sets
nRF      = RF / (2 (n - 3))      n = shared leaf count
nRF_sum  = RF / (s1 + s2)        s_i = non-trivial split counts (polytomy-aware)

Run with C:\\Python314\\python.exe (dendropy + numpy + scipy available).
"""
from __future__ import annotations

import os
import sys
import tempfile

import dendropy
from dendropy.calculate import treecompare


# --------------------------------------------------------------------------
# loading
# --------------------------------------------------------------------------
def _strip_noise(text: str) -> str:
    """Keep only the topology line(s); programs sometimes prefix stderr lines."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    kept = [ln for ln in lines if ln.startswith("(")]
    if not kept:
        raise ValueError("no topology line found")
    return "".join(kept)


def _read(text: str, tns: dendropy.TaxonNamespace) -> dendropy.Tree:
    return dendropy.Tree.get(
        data=_strip_noise(text), schema="newick",
        taxon_namespace=tns,
        rooting="force-unrooted",
        preserve_underscores=True,
        suppress_internal_node_taxa=True,
    )


def load(path_or_str: str) -> dendropy.Tree:
    tns = dendropy.TaxonNamespace()
    if os.path.exists(path_or_str):
        with open(path_or_str, encoding="utf-8", errors="replace") as fh:
            raw = fh.read()
    else:
        raw = path_or_str
    return _read(raw, tns)


# --------------------------------------------------------------------------
# explicit canonical split extraction (independent of dendropy bipartitions)
# --------------------------------------------------------------------------
def canonical_splits(tree: dendropy.Tree, ref_label: str) -> frozenset:
    """Non-trivial unrooted splits, canonicalised: keep the side WITHOUT ref."""
    leaves = {lf.taxon.label for lf in tree.leaf_node_iter()}
    n = len(leaves)
    full = frozenset(leaves)
    out = set()

    def leafset(node):
        s = set()
        stack = [node]
        while stack:
            nd = stack.pop()
            if nd.is_leaf():
                s.add(nd.taxon.label)
            else:
                stack.extend(nd.child_nodes())
        return frozenset(s)

    root = tree.seed_node
    # every node except the seed node defines the edge above it
    stack = [root]
    while stack:
        nd = stack.pop()
        for ch in nd.child_nodes():
            if not ch.is_leaf():
                side = leafset(ch)
                canon = (full - side) if ref_label in side else side
                if 1 < len(canon) < n - 1:
                    out.add(canon)
            stack.append(ch)
    return frozenset(out)


# --------------------------------------------------------------------------
# main entry
# --------------------------------------------------------------------------
def rf_parts(a, b):
    """a, b: file paths or Newick strings. Returns dict of RF decomposition."""
    tns = dendropy.TaxonNamespace()
    def get(x):
        if os.path.exists(x):
            with open(x, encoding="utf-8", errors="replace") as fh:
                return fh.read()
        return x
    t1 = _read(get(a), tns)
    t2 = _read(get(b), tns)

    l1 = {lf.taxon.label for lf in t1.leaf_node_iter()}
    l2 = {lf.taxon.label for lf in t2.leaf_node_iter()}
    common = l1 & l2
    if not common:
        raise ValueError("no shared leaves")
    if common != l1:
        t1.retain_taxa_with_labels(common)
    if common != l2:
        t2.retain_taxa_with_labels(common)

    # drop taxa not in `common` from the namespace so dendropy's
    # symmetric_difference operates on the shared label space
    for tx in [t for t in list(tns) if t.label not in common]:
        tns.remove_taxon(tx)

    t1.encode_bipartitions(suppress_unifurcations=False,
                           collapse_unrooted_basal_bifurcation=True)
    t2.encode_bipartitions(suppress_unifurcations=False,
                           collapse_unrooted_basal_bifurcation=True)

    rf_dendro = int(treecompare.symmetric_difference(t1, t2))

    ref = sorted(common)[0]
    s1 = canonical_splits(t1, ref)
    s2 = canonical_splits(t2, ref)
    rf_explicit = len(s1 - s2) + len(s2 - s1)

    ok = (rf_dendro == rf_explicit)
    n = len(common)
    denom = 2 * (n - 3)
    shared = len(s1 & s2)
    return {
        "n": n,
        "s1": len(s1),
        "s2": len(s2),
        "shared": shared,
        "RF": rf_explicit,
        "RF_dendro": rf_dendro,
        "agree": ok,
        "nRF": (rf_explicit / denom) if denom > 0 else float("nan"),
        "nRF_2n6": (rf_explicit / denom) if denom > 0 else float("nan"),
        "nRF_sum": (rf_explicit / (len(s1) + len(s2)))
                   if (len(s1) + len(s2)) > 0 else float("nan"),
    }


def nrf(a, b) -> float:
    return rf_parts(a, b)["nRF"]


# --------------------------------------------------------------------------
# rerooting invariance (defining property of a true unrooted RF)
# --------------------------------------------------------------------------
def rerooting_invariance(a, b, n_trials: int = 10):
    """nRF must be identical under arbitrary rerooting of either tree."""
    base = rf_parts(a, b)["nRF"]
    vals = []
    for tag, src in (("a", a), ("b", b)):
        t = load(src)
        leaves = list(t.leaf_node_iter())
        if len(leaves) < 4:
            break
        for i in range(n_trials):
            t = load(src)
            leaves = list(t.leaf_node_iter())
            tgt = leaves[(i * 7 + 3) % len(leaves)]
            try:
                t.reroot_at_edge(tgt.edge, suppress_unifurcations=False)
            except Exception:
                continue
            p = tempfile.mktemp(suffix=".nwk")
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(t.as_string(schema="newick",
                                     suppress_rooting=True,
                                     unquoted_underscores=True).replace("\n", ""))
            other = b if tag == "a" else a
            try:
                vals.append(rf_parts(p, other)["nRF"])
            finally:
                if os.path.exists(p):
                    os.unlink(p)
    return base, (min(vals) if vals else None), (max(vals) if vals else None)


if __name__ == "__main__":
    a, b = sys.argv[1], sys.argv[2]
    r = rf_parts(a, b)
    print("n=%(n)d s1=%(s1)d s2=%(s2)d shared=%(shared)d RF=%(RF)d "
          "(dendro=%(RF_dendro)d, agree=%(agree)s) nRF(2n-6)=%(nRF_2n6).4f "
          "nRF(sum)=%(nRF_sum).4f" % r)
