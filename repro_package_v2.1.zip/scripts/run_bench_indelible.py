#!/usr/bin/env python3
"""Benchmark runner for INDELible-generated data.

Same evaluation protocol as run_multi_scale_benchmark.py (MAFFT -> FastTree2
-nt -gtr -nosupport, Fusang k=5/gap2, nRF via calc_nrf_simple.py) but reads and
writes everything inside --data_dir so the JC69-era files in the repository
root are never touched.

Usage:
  python run_bench_indelible.py --n 200 --tag indel --seeds 230-259 \
      --data_dir indelible_n200_indel --out indelible_n200_indel.csv
"""
import argparse, csv, os, subprocess, sys

WORK_DIR = os.environ.get("REPO_DIR", r"d:\系统发育树项目\Fusang\Fusang-main")
MAFFT_DIR = r"C:\mafft_tmp\mafft-win"
MAFFT_TMP = os.path.join(MAFFT_DIR, "tmp")
# Toolchain defaults point at the pinned conda env `fusang_bench` (WSL); every
# path is overridable, e.g. to run under Windows with FastTree.exe + Python 3.14.
ENV_BIN = "/opt/miniconda3/envs/fusang_bench/bin"
MAFFT_BIN = os.environ.get("MAFFT_BIN", ENV_BIN + "/mafft")
FASTTREE = os.environ.get("FASTTREE_BIN", ENV_BIN + "/FastTree")
PYTHON = os.environ.get("FUSANG_PYTHON", ENV_BIN + "/python")
FUSANG_PY = os.path.join(WORK_DIR, "fusang_v2.py")
CALC_NRF = os.path.join(WORK_DIR, "calc_nrf_simple_SUPERSEDED.py")


def parse_seeds(spec):
    out = []
    for part in spec.split(','):
        part = part.strip()
        if '-' in part:
            lo, hi = part.split('-')
            out.extend(range(int(lo), int(hi) + 1))
        else:
            out.append(int(part))
    return sorted(set(out))


def _usable(path):
    return os.path.exists(path) and os.path.getsize(path) > 0


def calc_nrf(true_tree, pred_tree):
    r = subprocess.run([PYTHON, CALC_NRF, true_tree, pred_tree],
                       capture_output=True, text=True, cwd=WORK_DIR, timeout=120)
    for line in r.stdout.split('\n'):
        if 'nRF' in line and 'distance' in line:
            try:
                return float(line.split(':')[1].strip())
            except Exception:
                pass
    return None


def run_mafft(fasta, aligned):
    if MAFFT_BIN:                              # unix-style binary
        with open(aligned, 'w') as fout, open(aligned + '.err', 'w') as ferr:
            r = subprocess.run([MAFFT_BIN, '--auto', '--quiet', fasta],
                               stdout=fout, stderr=ferr, timeout=900)
        return r.returncode == 0 and os.path.getsize(aligned) > 0
    """Copy into MAFFT's own tmp dir and run mafft.bat --auto --quiet."""
    import shutil
    os.makedirs(MAFFT_TMP, exist_ok=True)
    base = os.path.basename(fasta)
    tmp_path = os.path.join(MAFFT_TMP, base)
    shutil.copy2(fasta, tmp_path)
    # shell redirection instead of a pipe: mafft.bat leaves a child holding the
    # stdout handle, which makes subprocess.run() block forever on Windows
    errf = aligned + '.err'
    cmd = 'mafft.bat --auto --quiet "tmp\\%s" > "%s" 2> "%s"' % (base, aligned, errf)
    r = subprocess.run(cmd, cwd=MAFFT_DIR, shell=True, timeout=900)
    return r.returncode == 0 and os.path.exists(aligned) and os.path.getsize(aligned) > 0


def run_fasttree(aligned, out_nwk):
    with open(aligned) as fin, open(out_nwk, 'w') as fout:
        r = subprocess.run([FASTTREE, '-nt', '-gtr', '-nosupport'],
                           stdin=fin, stdout=fout, stderr=subprocess.PIPE,
                           text=True, timeout=900)
    return r.returncode == 0 and os.path.getsize(out_nwk) > 0


def run_fusang(fasta, out_nwk, n):
    cmd = [PYTHON, FUSANG_PY, '--input', fasta, '--output', out_nwk,
           '--tree_method', 'nj', '--kmer_k', '5', '--kmer_gap', 'gap2']
    if n > 500:
        cmd += ['--auto_group_method', 'nj_centroid']
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=WORK_DIR, timeout=1800)
    return r.returncode == 0 and os.path.exists(out_nwk)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, required=True)
    ap.add_argument('--tag', default='indel')
    ap.add_argument('--seeds', required=True)
    ap.add_argument('--data_dir', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    data_dir = a.data_dir if os.path.isabs(a.data_dir) else os.path.join(WORK_DIR, a.data_dir)
    os.makedirs(data_dir, exist_ok=True)

    rows = []
    for seed in parse_seeds(a.seeds):
        fasta = os.path.join(data_dir, 'seed%d_%s.fasta' % (seed, a.tag))
        true_tree = os.path.join(data_dir, 'seed%d_%s_true.nwk' % (seed, a.tag))
        aligned = os.path.join(data_dir, 'seed%d_%s_aligned.fasta' % (seed, a.tag))
        ft2 = os.path.join(data_dir, 'seed%d_%s_ft2.nwk' % (seed, a.tag))
        fus = os.path.join(data_dir, 'seed%d_%s_fusang.nwk' % (seed, a.tag))
        if not os.path.exists(fasta) or not os.path.exists(true_tree):
            print('seed %d: MISSING input' % seed)
            rows.append((seed, None, None))
            continue
        if not _usable(aligned):
            if not run_mafft(fasta, aligned):
                print('seed %d: MAFFT failed' % seed)
                rows.append((seed, None, None))
                continue
        if not _usable(ft2):
            if not run_fasttree(aligned, ft2):
                print('seed %d: FastTree2 failed' % seed)
                rows.append((seed, None, None))
                continue
        if not _usable(fus):
            if not run_fusang(fasta, fus, a.n):
                print('seed %d: Fusang failed' % seed)
                rows.append((seed, None, None))
                continue
        nrf_ft2 = calc_nrf(true_tree, ft2)
        nrf_fus = calc_nrf(true_tree, fus)
        print('seed %d: nRF_ft2=%s nRF_fusang=%s' % (seed, nrf_ft2, nrf_fus))
        rows.append((seed, nrf_ft2, nrf_fus))

    out = a.out if os.path.isabs(a.out) else os.path.join(WORK_DIR, a.out)
    with open(out, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['seed', 'nrf_ft2', 'nrf_fusang'])
        for r in rows:
            w.writerow(r)
    ok = [r for r in rows if r[1] is not None and r[2] is not None]
    if ok:
        import statistics as st
        print('\n%s: %d/%d valid | FT2 %.4f+-%.4f | Fusang %.4f+-%.4f'
              % (a.out, len(ok), len(rows),
                 st.mean(r[1] for r in ok), st.pstdev(r[1] for r in ok),
                 st.mean(r[2] for r in ok), st.pstdev(r[2] for r in ok)))


if __name__ == '__main__':
    main()
