#!/usr/bin/env python3
"""Redo manuscript Table 5 (pipeline tier validation L0/L1/L3 vs true tree) on
INDELible v1.03 data, replacing the old hand-written coalescent simulator.

Protocol (identical to the old Table 5 coalescent protocol except the simulator):
  n=200 taxa, L=1000 bp root length, sub=0.05 (legacy scale -> sub_scale=0.005
  subs/site/branch), indel=0.02 (legacy scale -> INDELible [indelrate] 0.2 for
  insertion and deletion each), GTR+Gamma(alpha=1.0, 4 cat), NB(2/3,1) indel
  lengths, birth-death conditioned tree (the homogeneous/"coalescent" case of
  gen_indelible_sim.py).

Tiers per seed:
  L0: spaced k-mer k=5 gap2 (mask 1110011) cosine distance + BioPython NJ (no NNI)
  L1: multi-k ensemble = mean of contiguous cosine k=5,7,9 matrices + BioPython NJ
  L3: MAFFT --auto -> FastTree2 -nt -gtr -nosupport

nRF convention (calc_nrf_simple.py): RF=|bp1-bp2|+|bp2-bp1|, nRF=RF/(2(n-3)).

Must be run inside WSL fusang_bench env (INDELible, MAFFT, FastTree on PATH):
  python3 bench_table5_coalescent_indelible.py --seeds 300-329 --workers 2
"""

import argparse
import csv
import json
import os
import random
import shutil
import subprocess
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.setrecursionlimit(10000)

import gen_indelible_sim as gis  # noqa: E402
from af_competitor_methods import kmer_cosine_distance_matrix, read_fasta  # noqa: E402
from fusang_v4_dahp_v1 import build_nj  # noqa: E402
from calc_nrf_simple_SUPERSEDED import get_bipartitions_from_newick  # noqa: E402

GAP2_MASK = "1110011"  # Fusang gap2 for k=5: positions 0,1,2,5,6 in a 7-bp window


def nrf_from_newick(nwk_a, nwk_b):
    try:
        leaves_a, bp_a = get_bipartitions_from_newick(nwk_a)
        leaves_b, bp_b = get_bipartitions_from_newick(nwk_b)
    except Exception:
        return float("nan")
    if not bp_a or not bp_b:
        return float("nan")
    rf = len(bp_a - bp_b) + len(bp_b - bp_a)
    n = len(leaves_a | leaves_b)
    denom = 2 * (n - 3)
    return rf / denom if denom > 0 else float("nan")


def generate_one(seed, n, L, sub, indel, data_dir):
    """One INDELible dataset: <data_dir>/seed{seed}_tab5.fasta + _true.nwk"""
    fasta = os.path.join(data_dir, "seed%d_tab5.fasta" % seed)
    true_nwk = os.path.join(data_dir, "seed%d_tab5_true.nwk" % seed)
    if os.path.exists(fasta) and os.path.exists(true_nwk):
        return fasta, true_nwk

    workdir = os.path.join(data_dir, "_indelible_seed%d" % seed)
    shutil.rmtree(workdir, ignore_errors=True)
    os.makedirs(workdir)

    rng = random.Random(seed)
    tree = gis.birth_death_tree(n, rng)
    gis.scale_tree(tree, 0.005 / gis.mean_branch_length(tree))
    nwk = gis.newick(tree, prefix="seq")

    indel_rel = 0.5 * indel / sub
    ctl = gis.CONTROL.format(seed=seed, rates="0.2 0.4 0.6 0.8 1.2", alpha=1.0,
                             ncat=4, nbq=2.0 / 3.0, indelrate=indel_rel,
                             tree=nwk, L=L, name="sim")
    with open(os.path.join(workdir, "control.txt"), "w") as fh:
        fh.write(ctl)
    r = subprocess.run(["indelible", "control.txt"], cwd=workdir,
                       capture_output=True, text=True)
    sim_fas = os.path.join(workdir, "sim.fas")
    if r.returncode != 0 or not os.path.exists(sim_fas):
        raise RuntimeError("INDELible failed seed=%d rc=%s: %s %s"
                           % (seed, r.returncode, r.stdout[-500:], r.stderr[-500:]))
    shutil.copyfile(sim_fas, fasta)
    sim_true = os.path.join(workdir, "sim_TRUE.tree")
    if os.path.exists(sim_true):
        shutil.copyfile(sim_true, true_nwk)
    else:
        with open(true_nwk, "w") as fh:
            fh.write(nwk + "\n")
    shutil.rmtree(workdir, ignore_errors=True)
    return fasta, true_nwk


def run_l3(fasta, seed, data_dir):
    """MAFFT --auto -> FastTree2 -nt -gtr -nosupport. Returns (nwk, seconds)."""
    aligned = os.path.join(data_dir, "seed%d_tab5_aligned.fasta" % seed)
    tree_path = os.path.join(data_dir, "seed%d_tab5_ft2.nwk" % seed)
    t0 = time.time()
    with open(aligned, "w") as out:
        r = subprocess.run(["mafft", "--auto", "--thread", "1", fasta],
                           stdout=out, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        raise RuntimeError("mafft failed seed=%d: %s" % (seed, r.stderr[-500:]))
    with open(tree_path, "w") as out:
        r = subprocess.run(["FastTree", "-nt", "-gtr", "-nosupport", aligned],
                           stdout=out, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        raise RuntimeError("FastTree failed seed=%d: %s" % (seed, r.stderr[-500:]))
    with open(tree_path) as fh:
        nwk = fh.read().strip()
    return nwk, time.time() - t0


def process_seed(task):
    seed, n, L, sub, indel, data_dir = task
    row = {"seed": seed}
    t0 = time.time()
    try:
        fasta, true_path = generate_one(seed, n, L, sub, indel, data_dir)
        with open(true_path) as fh:
            true_nwk = fh.read().strip()

        seqs_dict = read_fasta(fasta)
        names = list(seqs_dict.keys())
        seqs = [seqs_dict[nm] for nm in names]

        # L0: spaced k=5 gap2 cosine + NJ
        t_l0 = time.time()
        D0 = kmer_cosine_distance_matrix(seqs, names, k=5, gap_pattern=GAP2_MASK)
        nwk0 = build_nj(np.asarray(D0, dtype=np.float64), names)
        row["l0_true"] = nrf_from_newick(nwk0, true_nwk)
        row["seconds_l0"] = round(time.time() - t_l0, 1)

        # L1: multi-k ensemble contiguous k=5,7,9 mean + NJ
        t_l1 = time.time()
        mats = [np.asarray(kmer_cosine_distance_matrix(seqs, names, k=k),
                           dtype=np.float64) for k in (5, 7, 9)]
        D1 = (mats[0] + mats[1] + mats[2]) / 3.0
        nwk1 = build_nj(D1, names)
        row["l1_true"] = nrf_from_newick(nwk1, true_nwk)
        row["seconds_l1"] = round(time.time() - t_l1, 1)

        # L3: MAFFT -> FastTree2
        nwk3, sec3 = run_l3(fasta, seed, data_dir)
        row["l3_true"] = nrf_from_newick(nwk3, true_nwk)
        row["seconds_l3"] = round(sec3, 1)
    except Exception as exc:
        row["error"] = str(exc)
    row["seconds_total"] = round(time.time() - t0, 1)
    return row


def parse_seed_spec(spec):
    out = []
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = part.split("-")
            out.extend(range(int(lo), int(hi) + 1))
        elif part:
            out.append(int(part))
    return sorted(set(out))


def paired_stats(a, b):
    """a, b: paired arrays. Returns dict with Wilcoxon (zsplit) p, Cohen's d, wins."""
    from scipy import stats
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    diff = b - a
    wins = int(np.sum(b < a))
    losses = int(np.sum(b > a))
    ties = int(np.sum(b == a))
    try:
        _, p = stats.wilcoxon(a, b, zero_method="zsplit")
        p = float(p)
    except Exception:
        p = None
    sd = float(np.std(diff, ddof=1))
    d = float(np.mean(diff) / sd) if sd > 0 else 0.0
    return {"wilcoxon_p_zsplit": p, "cohens_d_paired": d,
            "wins_b_lt_a": wins, "losses": losses, "ties": ties,
            "mean_diff_b_minus_a": float(np.mean(diff))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="300-329")
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--L", type=int, default=1000)
    ap.add_argument("--sub", type=float, default=0.05)
    ap.add_argument("--indel", type=float, default=0.02)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--dir", default="bench_l3_coalescent_indelible")
    ap.add_argument("--out", default="bench_l3_coalescent_indelible_30seeds.csv")
    args = ap.parse_args()

    data_dir = args.dir if os.path.isabs(args.dir) else os.path.join(HERE, args.dir)
    os.makedirs(data_dir, exist_ok=True)
    cache_dir = os.path.join(data_dir, ".cache")
    os.makedirs(cache_dir, exist_ok=True)
    seeds = parse_seed_spec(args.seeds)

    rows = []
    for fn in sorted(os.listdir(cache_dir)):
        if fn.startswith("seed") and fn.endswith(".json"):
            try:
                with open(os.path.join(cache_dir, fn)) as fh:
                    r = json.load(fh)
                if r.get("seed") in seeds and "l3_true" in r:
                    rows.append(r)
            except Exception:
                pass
    done = {r["seed"] for r in rows}
    if done:
        print("resume: %d seeds cached" % len(done), flush=True)

    tasks = [(s, args.n, args.L, args.sub, args.indel, data_dir)
             for s in seeds if s not in done]
    t0 = time.time()
    n_total = len(seeds)

    def handle(row):
        rows.append(row)
        tmp = os.path.join(cache_dir, "seed%d.json.tmp" % row["seed"])
        with open(tmp, "w") as fh:
            json.dump(row, fh)
        os.replace(tmp, os.path.join(cache_dir, "seed%d.json" % row["seed"]))
        print("[%d/%d] seed %d  l0=%.4f l1=%.4f l3=%.4f  (%.0fs elapsed)%s"
              % (len(rows), n_total, row["seed"],
                 row.get("l0_true", float("nan")), row.get("l1_true", float("nan")),
                 row.get("l3_true", float("nan")), time.time() - t0,
                 " ERROR:" + row["error"] if row.get("error") else ""), flush=True)

    if args.workers > 1:
        with Pool(processes=args.workers) as pool:
            for row in pool.imap_unordered(process_seed, tasks):
                handle(row)
    else:
        for t in tasks:
            handle(process_seed(t))

    rows.sort(key=lambda r: r["seed"])
    cols = ["seed", "l0_true", "l1_true", "l3_true",
            "seconds_l0", "seconds_l1", "seconds_l3", "seconds_total", "error"]
    csv_path = args.out if os.path.isabs(args.out) else os.path.join(HERE, args.out)
    with open(csv_path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print("wrote %s" % csv_path)

    ok = [r for r in rows if isinstance(r.get("l3_true"), float)]
    l0 = np.array([r["l0_true"] for r in ok])
    l1 = np.array([r["l1_true"] for r in ok])
    l3 = np.array([r["l3_true"] for r in ok])
    sec3 = np.array([r["seconds_l3"] for r in ok])

    def ms(x):
        return "%.4f ± %.4f" % (float(np.mean(x)), float(np.std(x, ddof=1)))

    summary = {
        "protocol": {
            "simulator": "INDELible v1.03 (GTR+Gamma a=1.0 4cat; NB(2/3,1) indel "
                         "lengths; birth-death conditioned tree = homogeneous/"
                         "coalescent case of gen_indelible_sim.py)",
            "n": args.n, "L": args.L, "sub_legacy": args.sub,
            "indel_legacy": args.indel,
            "indelrate_indelible": 0.5 * args.indel / args.sub,
            "seeds": [seeds[0], seeds[-1]], "n_scored": len(ok),
            "L0": "spaced k=5 gap2 (1110011) cosine + BioPython NJ (no NNI)",
            "L1": "mean of contiguous cosine k=5,7,9 + BioPython NJ (no NNI)",
            "L3": "MAFFT --auto -> FastTree2 -nt -gtr -nosupport",
            "nrf": "RF=|bp1-bp2|+|bp2-bp1|; nRF=RF/(2(n-3)) (calc_nrf_simple.py)",
        },
        "tiers": {
            "L0": {"mean": float(np.mean(l0)), "sd": float(np.std(l0, ddof=1))},
            "L1": {"mean": float(np.mean(l1)), "sd": float(np.std(l1, ddof=1))},
            "L3": {"mean": float(np.mean(l3)), "sd": float(np.std(l3, ddof=1)),
                   "seconds_mean": float(np.mean(sec3))},
        },
        "paired": {
            "L1_vs_L0": paired_stats(l0, l1),
            "L1_vs_L3": paired_stats(l3, l1),
            "L0_vs_L3": paired_stats(l3, l0),
        },
    }
    json_path = csv_path.replace(".csv", "_summary.json")
    with open(json_path, "w") as fh:
        json.dump(summary, fh, indent=2)
    print("wrote %s" % json_path)

    print("\n=== Table 5 redo (INDELible, seeds %d-%d, n=%d) ==="
          % (seeds[0], seeds[-1], len(ok)))
    print("L0 (spaced k5 NJ):   %s" % ms(l0))
    print("L1 (multi-k NJ):     %s" % ms(l1))
    print("L3 (MAFFT+FT2):      %s   (MAFFT+FT2 mean %.1fs/seed)" % (ms(l3), np.mean(sec3)))
    for key, (a, b, lab) in (("L1_vs_L0", (l0, l1, "L1 vs L0")),
                             ("L1_vs_L3", (l3, l1, "L1 vs L3")),
                             ("L0_vs_L3", (l3, l0, "L0 vs L3"))):
        s = summary["paired"][key]
        print("%s: p(zsplit)=%s d=%.2f wins=%d/%d mean_diff=%.4f"
              % (lab, ("%.3g" % s["wilcoxon_p_zsplit"]) if s["wilcoxon_p_zsplit"] is not None else "NA",
                 s["cohens_d_paired"], s["wins_b_lt_a"], len(ok), s["mean_diff_b_minus_a"]))


if __name__ == "__main__":
    main()
