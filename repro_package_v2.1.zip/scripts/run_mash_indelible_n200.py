#!/usr/bin/env python3
"""
Table 2 redo: Mash MinHash benchmark on INDELible n=200 data (130 seeds).

Per seed/condition:
  1. mash sketch -k 21 -s 10000 (same as legacy mash_benchmark_wsl2.py;
     seq len ~500 bp -> #k-mers < 1000, so s=1000 vs s=10000 identical)
  2. mash dist -> 200x200 Jaccard-derived Mash distance matrix
  3. NJ tree (BioPython DistanceTreeConstructor)
  4. FastME tree (FastME 2.1.6.3, defaults) from same matrix
  5. nRF vs true tree and vs ft2 tree, using calc_nrf_simple.get_bipartitions_from_newick
     (rf = |bp1-bp2|+|bp2-bp1|, nRF = rf/(2*(n-3)))
"""

import os
import sys
import csv
import subprocess
import tempfile
from concurrent.futures import ProcessPoolExecutor, as_completed

BASE = "/mnt/d/系统发育树项目/Fusang/Fusang-main"
MASH = "/opt/miniconda3/envs/skmer/bin/mash"
FASTME = "/opt/miniconda3/envs/c_layer_ortho/bin/fastme"
K = 21
S = 10000
SEEDS = list(range(100, 230))
CONDITIONS = ["clean", "indel"]
WORK = os.path.join(BASE, "mash_indelible_n200_work")

sys.path.insert(0, BASE)
from calc_nrf_simple_SUPERSEDED import get_bipartitions_from_newick


def nrf_from_files(p1, p2):
    with open(p1, encoding="utf-8", errors="ignore") as f:
        n1 = f.read()
    with open(p2, encoding="utf-8", errors="ignore") as f:
        n2 = f.read()
    leaves1, bp1 = get_bipartitions_from_newick(n1)
    leaves2, bp2 = get_bipartitions_from_newick(n2)
    all_leaves = leaves1 | leaves2
    if leaves1 != leaves2:
        raise ValueError(f"leaf mismatch: {p1} vs {p2}")
    rf = len(bp1 - bp2) + len(bp2 - bp1)
    n = len(all_leaves)
    return rf / (2.0 * (n - 3))


def nj_tree_biopython(names, matrix, out_path):
    from Bio.Phylo.TreeConstruction import DistanceMatrix, DistanceTreeConstructor
    from Bio import Phylo
    n = len(names)
    lower = [[matrix[i][j] for j in range(i + 1)] for i in range(n)]
    dm = DistanceMatrix(names=list(names), matrix=lower)
    ctor = DistanceTreeConstructor()
    tree = ctor.nj(dm)
    Phylo.write(tree, out_path, "newick")


def fastme_tree(names, matrix, work_dir, out_path):
    n = len(names)
    phy = os.path.join(work_dir, "in.phy")
    with open(phy, "w") as f:
        f.write(f"{n}\n")
        for i in range(n):
            row = " ".join(f"{matrix[i][j]:.8f}" for j in range(n))
            f.write(f"{names[i]}  {row}\n")
    r = subprocess.run([FASTME, "-i", phy, "-o", out_path],
                       capture_output=True, text=True, cwd=work_dir)
    if r.returncode != 0 or not os.path.exists(out_path):
        raise RuntimeError(f"fastme failed: {r.stderr[-300:]}")


def process_one(seed, cond):
    data_dir = os.path.join(BASE, f"indelible_n200_{cond}")
    fasta = os.path.join(data_dir, f"seed{seed}_{cond}.fasta")
    true_nwk = os.path.join(data_dir, f"seed{seed}_{cond}_true.nwk")
    ft2_nwk = os.path.join(data_dir, f"seed{seed}_{cond}_ft2.nwk")

    sd = os.path.join(WORK, f"seed{seed}_{cond}")
    os.makedirs(sd, exist_ok=True)
    sketch = os.path.join(sd, "sketch")

    r = subprocess.run([MASH, "sketch", "-i", "-k", str(K), "-s", str(S),
                        "-o", sketch, fasta], capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"mash sketch failed seed{seed} {cond}: {r.stderr[-300:]}")

    r = subprocess.run([MASH, "dist", sketch + ".msh", sketch + ".msh"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"mash dist failed seed{seed} {cond}: {r.stderr[-300:]}")

    dist = {}
    names = set()
    for line in r.stdout.strip().split("\n"):
        p = line.split("\t")
        if len(p) < 3:
            continue
        a, b, d = p[0], p[1], float(p[2])
        names.add(a); names.add(b)
        dist[(a, b)] = d
        dist[(b, a)] = d
    names = sorted(names, key=lambda x: int(x[1:]) if x[0] == "t" and x[1:].isdigit() else x)
    n = len(names)
    if n != 200:
        raise RuntimeError(f"expected 200 taxa, got {n} seed{seed} {cond}")
    matrix = [[dist[(a, b)] if a != b else 0.0 for b in names] for a in names]

    nj_nwk = os.path.join(sd, "mash_nj.nwk")
    nj_tree_biopython(names, matrix, nj_nwk)

    fm_nwk = os.path.join(sd, "mash_fastme.nwk")
    fastme_tree(names, matrix, sd, fm_nwk)

    return {
        "seed": seed,
        "condition": cond,
        "mash_nj_true": nrf_from_files(nj_nwk, true_nwk),
        "mash_nj_ft2": nrf_from_files(nj_nwk, ft2_nwk),
        "mash_fastme_true": nrf_from_files(fm_nwk, true_nwk),
        "mash_fastme_ft2": nrf_from_files(fm_nwk, ft2_nwk),
    }


def main():
    os.makedirs(WORK, exist_ok=True)
    only_seed = int(sys.argv[1]) if len(sys.argv) > 1 else None
    jobs = [(s, c) for s in SEEDS for c in CONDITIONS
            if only_seed is None or s == only_seed]
    out_csv = os.path.join(BASE, "bench_mash_indelible_n200.csv")
    fields = ["seed", "condition", "mash_nj_true", "mash_nj_ft2",
              "mash_fastme_true", "mash_fastme_ft2"]
    results = []
    done = 0
    with ProcessPoolExecutor(max_workers=2) as ex:
        futs = {ex.submit(process_one, s, c): (s, c) for s, c in jobs}
        for fut in as_completed(futs):
            s, c = futs[fut]
            try:
                row = fut.result()
                results.append(row)
            except Exception as e:
                print(f"ERROR seed{s} {c}: {e}", flush=True)
            done += 1
            if done % 10 == 0:
                print(f"progress {done}/{len(jobs)}", flush=True)
    results.sort(key=lambda r: (r["condition"], r["seed"]))
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in results:
            w.writerow(r)
    print(f"wrote {out_csv} with {len(results)} rows")


if __name__ == "__main__":
    main()
