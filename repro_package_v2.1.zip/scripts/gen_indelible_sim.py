#!/usr/bin/env python3
"""Generate benchmark datasets with INDELible (replaces gen_test_data_indel.py).

Model matches the manuscript's declared simulation design:
  - substitution: GTR + Gamma (alpha=1.0, 4 rate categories)
  - tree prior   : birth-death (lambda=1.0, mu=0.5), conditioned on n extant tips
  - root length  : L=500 bp
  - indels       : geometric length distribution (mean 3 bp), insertion:deletion = 1:1
  - indel rate   : relative to the substitution rate (INDELible's [indelrate] scale)

Scale convention (keeps the new data comparable to the previous JC69 benchmark):
  previous simulator: expected substitutions per branch = sub_rate * bl * L
                    = 0.05 * 0.1 * L  ->  0.005 subs/site/branch
  So branch lengths are rescaled so that the mean root-to-tip distance equals
  0.005 * d_ref(n), where d_ref(n) is the mean root-to-tip edge count of the
  previous coalescent generator.  indel_rate 0.02 (old scale) = 0.4 relative
  to a substitution rate of 1, because 0.02 / 0.05 = 0.4.

Usage:
  python3 gen_indelible_sim.py --n 200 --L 500 --indel 0.02 --seed 100 \
      --outdir /mnt/d/.../Fusang-main [--tag indel] [--keep]
Outputs: <outdir>/seed{seed}_{tag}.fasta  and  <outdir>/seed{seed}_{tag}_true.nwk
"""
import argparse, math, os, random, shutil, subprocess, sys

# ---------------------------------------------------------------- birth-death tree
class Node:
    __slots__ = ('children', 'bl', 'parent', 'alive')
    def __init__(self, parent=None, bl=0.0):
        self.children = []
        self.bl = bl
        self.parent = parent
        self.alive = True


def birth_death_tree(n, rng, lam=1.0, mu=0.5):
    """Forward birth-death simulation conditioned on exactly n extant tips.

    Returns the root Node of the *reconstructed* tree (extinct lineages pruned).
    """
    while True:
        root = Node()
        active = [(root, 0.0)]          # (node, time it started)
        t = 0.0
        nodes = [root]
        while True:
            k = len(active)
            if k == 0:
                break                    # whole clade died -> retry
            rate = k * (lam + mu)
            t += rng.expovariate(rate)
            idx = rng.randrange(k)
            node, tb = active[idx]
            if rng.random() < lam / (lam + mu):          # speciation
                node.bl = t - tb
                for _ in range(2):
                    c = Node(parent=node, bl=0.0)
                    node.children.append(c)
                    nodes.append(c)
                    active.append((c, t))
                active.pop(idx)
            else:                                        # extinction
                node.bl = t - tb
                node.alive = False
                active.pop(idx)
            if len(active) == n:
                # tips extend from their last event to the sampling time;
                # that waiting time is exponential with rate n*(lambda+mu)
                dt_next = rng.expovariate(n * (lam + mu))
                for nd, tb in active:
                    nd.bl = (t + dt_next) - tb
                break
            if len(active) == 0:
                break
        if len(active) == n and root.alive:
            return _prune_extinct(root)
        # else: retry


def _prune_extinct(root):
    """Remove lineages without extant descendants, merging branch lengths."""
    def rec(nd):
        if not nd.children:
            return nd if nd.alive else None
        kids = [k for k in (rec(c) for c in nd.children) if k is not None]
        if not kids:
            return None
        if len(kids) == 1:                     # collapse unifurcation
            only = kids[0]
            only.bl += nd.bl
            return only
        nd.children = kids
        for k in kids:
            k.parent = nd
        return nd
    out = rec(root)
    if out is None:
        raise RuntimeError('prune produced empty tree')
    return out


def mean_branch_length(root):
    """Mean branch length over all edges (n-1 internal + n terminal)."""
    tot, cnt = 0.0, 0
    def rec(nd):
        nonlocal tot, cnt
        if nd.parent is not None:              # skip the root's own (unused) length
            tot += nd.bl
            cnt += 1
        for c in nd.children:
            rec(c)
    rec(root)
    return tot / cnt


def mean_root_to_tip(root):
    """Mean root-to-tip distance (in branch-length units)."""
    tot, cnt = 0.0, 0
    def rec(nd, d):
        nonlocal tot, cnt
        d += nd.bl
        if not nd.children:
            tot += d
            cnt += 1
            return
        for c in nd.children:
            rec(c, d)
    rec(root, 0.0)
    return tot / cnt


def scale_tree(root, factor):
    def rec(nd):
        nd.bl *= factor
        for c in nd.children:
            rec(c)
    rec(root)


def newick(root, prefix='seq'):
    # name leaves in traversal order; INDELible rejects a branch length on the root
    names = []

    def rec2(nd, is_root=False):
        if not nd.children:
            nm = '%s%d' % (prefix, len(names))
            names.append(nm)
            return '%s:%.6f' % (nm, max(nd.bl, 1e-6))
        inner = ','.join(rec2(c) for c in nd.children)
        if is_root:
            return '(%s)' % inner
        return '(%s):%.6f' % (inner, max(nd.bl, 1e-6))

    return rec2(root, is_root=True) + ';'


def coalescent_ref_depth(n, trials=20, seed0=90000):
    """Mean root-to-tip *edge count* of the previous coalescent generator."""
    tot = 0.0
    for s in range(trials):
        rng = random.Random(seed0 + s)
        # Kingman coalescent: repeatedly merge two random lineages
        active = [Node() for _ in range(n)]
        depth = {}
        for nd in active:
            depth[id(nd)] = 0
        while len(active) > 1:
            i = rng.randrange(len(active))
            a = active.pop(i)
            j = rng.randrange(len(active))
            b = active.pop(j)
            p = Node()
            p.children = [a, b]
            depth[id(p)] = 1 + max(depth[id(a)], depth[id(b)])
            active.append(p)
        tot += depth[id(active[0])]
    return tot / trials


# ---------------------------------------------------------------- INDELible driver
CONTROL = """[TYPE] NUCLEOTIDE 1

[SETTINGS]
  [randomseed] {seed}
  [output] FASTA

[MODEL] gtrgamma
  [submodel]  GTR {rates}
  [statefreq] 0.25 0.25 0.25 0.25
  [rates]     0 {alpha} {ncat}
  [indelmodel] NB {nbq} 1
  [indelrate]  {indelrate}

[TREE] t1 {tree}

[PARTITIONS] P [t1 gtrgamma {L}]

[EVOLVE] P 1 {name}
"""


def run_indelible(workdir, control_name, use_wsl):
    if use_wsl:
        cmd = ['wsl', '-d', 'Ubuntu-24.04', '--', 'bash', '-c',
               "cd '%s' && indelible %s" % (workdir, control_name)]
    else:
        cmd = ['indelible', control_name]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=workdir if not use_wsl else None)
    return r


def parse_seeds(spec):
    """'100-229' or '100,101,102' -> list of ints."""
    out = []
    for part in spec.split(','):
        part = part.strip()
        if '-' in part:
            lo, hi = part.split('-')
            out.extend(range(int(lo), int(hi) + 1))
        else:
            out.append(int(part))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=200)
    ap.add_argument('--L', type=int, default=500)
    ap.add_argument('--sub', type=float, default=0.05, help='legacy scale; fixed at 0.05')
    ap.add_argument('--indel', type=float, default=0.02, help='legacy scale indel rate')
    ap.add_argument('--seed', type=int, default=None)
    ap.add_argument('--seeds', default=None, help='"100-229" or "100,101"')
    ap.add_argument('--outdir', default='.')
    ap.add_argument('--tag', default='indel')
    ap.add_argument('--name', default='sim')
    ap.add_argument('--keep', action='store_true', help='keep raw INDELible outputs')
    ap.add_argument('--wsl', action='store_true', help='call indelible through WSL')
    ap.add_argument('--workdir', default=None, help='WSL-side scratch dir (ASCII path)')
    ap.add_argument('--nbq', type=float, default=2.0 / 3.0, help='NB(q,r=1); mean indel len = 1+q/(1-q)')
    ap.add_argument('--sub_scale', type=float, default=0.005,
                    help='expected substitutions per site per branch (default 0.005)')
    ap.add_argument('--prefix', default='seq', help='leaf name prefix (e.g. t for t0001)')
    ap.add_argument('--quiet', action='store_true')
    a = ap.parse_args()

    seeds = parse_seeds(a.seeds) if a.seeds else ([a.seed] if a.seed is not None else [])
    if not seeds:
        ap.error('give --seed or --seeds')

    # indel length: INDELible NB(q,r) has mean = 1 + r*q/(1-q)  (control.cpp:1328)
    #   -> q = 2/3 with r=1 gives mean 3 bp, i.e. the geometric(mean=3) of the
    #      previous simulator
    nbq = a.nbq
    # [indelrate] sets the insertion rate AND the deletion rate (each) relative
    # to a substitution rate of 1, so the total indel event rate is 2x the value.
    # Previous simulator: indel events / substitutions = indel_rate / sub_rate,
    # hence indelrate = 0.5 * indel_rate / sub_rate  (= 0.2 for 0.02 / 0.05)
    indel_rel = 0.5 * a.indel / a.sub
    rates = '0.2 0.4 0.6 0.8 1.2'               # GTR exchangeabilities (a..e, f=1)

    workdir = a.workdir or os.path.join(a.outdir, '_indelible_run')
    os.makedirs(workdir, exist_ok=True)
    os.makedirs(a.outdir, exist_ok=True)

    for seed in seeds:
        rng = random.Random(seed)
        tree = birth_death_tree(a.n, rng)
        # every branch carries `sub_scale` expected substitutions/site; 0.005 is
        # the previous simulator's sub_rate(0.05) * bl(0.1) convention
        scale_tree(tree, a.sub_scale / mean_branch_length(tree))
        nwk = newick(tree, prefix=a.prefix)

        ctl = CONTROL.format(seed=seed, rates=rates, alpha=1.0, ncat=4,
                             nbq=nbq, indelrate=indel_rel, tree=nwk, L=a.L, name=a.name)
        open(os.path.join(workdir, 'control.txt'), 'w').write(ctl)

        r = run_indelible(workdir, 'control.txt', a.wsl)
        if r.returncode != 0 or not os.path.exists(os.path.join(workdir, a.name + '.fas')):
            sys.stderr.write('INDELIBLE FAILED seed=%d rc=%s\n%s\n%s\n'
                             % (seed, r.returncode, r.stdout[-1500:], r.stderr[-1500:]))
            sys.exit(1)

        out_fas = os.path.join(a.outdir, 'seed%d_%s.fasta' % (seed, a.tag))
        out_nwk = os.path.join(a.outdir, 'seed%d_%s_true.nwk' % (seed, a.tag))
        shutil.copyfile(os.path.join(workdir, a.name + '.fas'), out_fas)
        true_tree = os.path.join(workdir, a.name + '_TRUE.tree')
        if os.path.exists(true_tree):
            shutil.copyfile(true_tree, out_nwk)
        else:
            open(out_nwk, 'w').write(nwk + '\n')

        if not a.keep:
            for fn in os.listdir(workdir):
                os.remove(os.path.join(workdir, fn))

        if a.quiet:
            continue
        print('seed=%d n=%d meanBL=%.5f meanR2T=%.4f indel_rel=%.3f -> %s'
              % (seed, a.n, mean_branch_length(tree), mean_root_to_tip(tree),
                 indel_rel, os.path.basename(out_fas)))
    print('generated %d datasets (n=%d, L=%d, indel=%g) in %s' % (len(seeds), a.n, a.L, a.indel, a.outdir))


if __name__ == '__main__':
    main()
