#!/usr/bin/env python3
import argparse
import csv
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parent.parent
BENCH = ROOT / "bench_n1000_threshold"
DATA = ROOT / "indelible_n1000_clean"
DENOM = 2 * (1000 - 3)


def parse_seeds(spec):
    seeds = []
    for part in spec.split(","):
        if "-" in part:
            lo, hi = map(int, part.split("-", 1))
            seeds.extend(range(lo, hi + 1))
        else:
            seeds.append(int(part))
    return sorted(set(seeds))


def run_mode(mode, seeds):
    records = []
    flag = ["--auto_group_method", "simple"] if mode == "simple" else ["--auto_group_method", "nj_centroid"]
    for seed in seeds:
        fasta = DATA / f"seed{seed}_clean.fasta"
        output = BENCH / f"seed{seed}_clean_{mode}.nwk"
        log = BENCH / f"seed{seed}_clean_{mode}.log"
        if output.exists() and output.stat().st_size:
            records.append({"seed": seed, "mode": mode, "status": "reused", "seconds": None})
            print(f"seed {seed} {mode}: reused", flush=True)
            continue
        cmd = [
            sys.executable,
            str(ROOT / "fusang_v2.py"),
            "--input", str(fasta),
            "--output", str(output),
            "--tree_method", "nj",
            "--kmer_k", "5",
            "--kmer_gap", "gap2",
            *flag,
        ]
        started = time.perf_counter()
        status = "ok"
        returncode = None
        error = None
        try:
            with log.open("w", encoding="utf-8") as handle:
                result = subprocess.run(
                    cmd,
                    cwd=ROOT,
                    stdout=handle,
                    stderr=subprocess.STDOUT,
                    timeout=900,
                )
            returncode = result.returncode
            if result.returncode != 0 or not output.exists() or not output.stat().st_size:
                status = "failed"
        except subprocess.TimeoutExpired:
            status = "timeout"
            error = "exceeded 900 seconds"
        except Exception as exc:
            status = "failed"
            error = repr(exc)
        seconds = time.perf_counter() - started
        record = {
            "seed": seed,
            "mode": mode,
            "status": status,
            "seconds": seconds,
            "returncode": returncode,
            "error": error,
            "command": cmd,
        }
        records.append(record)
        print(f"seed {seed} {mode}: {status}, {seconds:.3f} s", flush=True)
    with (BENCH / f"runtime_{mode}.json").open("w", encoding="utf-8") as handle:
        json.dump(records, handle, indent=2, ensure_ascii=False)
    return 0 if all(record["status"] in {"ok", "reused"} for record in records) else 1


def summarize(seeds):
    sys.path.insert(0, str(ROOT))
    from nrf_standard import nrf, read_newick, rf_distance, splits

    rows = []
    for seed in seeds:
        true_path = DATA / f"seed{seed}_clean_true.nwk"
        simple_path = BENCH / f"seed{seed}_clean_simple.nwk"
        dcm_path = BENCH / f"seed{seed}_clean_dcm.nwk"
        archive_path = DATA / f"seed{seed}_clean_fusang.nwk"
        if not simple_path.exists() or not dcm_path.exists():
            continue
        true_tree = read_newick(str(true_path))
        simple_tree = read_newick(str(simple_path))
        dcm_tree = read_newick(str(dcm_path))
        archive_tree = read_newick(str(archive_path))
        rf_simple = rf_distance(true_tree, simple_tree)
        rf_dcm = rf_distance(true_tree, dcm_tree)
        nrf_simple = nrf(true_tree, simple_tree)
        nrf_dcm = nrf(true_tree, dcm_tree)
        if not np.isclose(nrf_simple, rf_simple / DENOM) or not np.isclose(nrf_dcm, rf_dcm / DENOM):
            raise RuntimeError(f"seed {seed}: nRF and integer RF disagree")
        rows.append({
            "seed": seed,
            "nrf_simple": nrf_simple,
            "nrf_dcm": nrf_dcm,
            "rf_diff_simple_minus_dcm": rf_simple - rf_dcm,
            "rf_simple": rf_simple,
            "rf_dcm": rf_dcm,
            "splits_true": len(splits(true_tree)),
            "splits_simple": len(splits(simple_tree)),
            "splits_dcm": len(splits(dcm_tree)),
            "archived_rf": rf_distance(true_tree, archive_tree),
            "archived_vs_rerun_dcm_rf": rf_distance(archive_tree, dcm_tree),
        })
    if not rows:
        raise RuntimeError("no complete seed pairs")

    output_csv = ROOT / "table_threshold_n1000_nrfstandard.csv"
    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["seed", "nrf_simple", "nrf_dcm", "rf_diff_simple_minus_dcm"])
        for row in rows:
            writer.writerow([
                row["seed"],
                f'{row["nrf_simple"]:.9f}',
                f'{row["nrf_dcm"]:.9f}',
                row["rf_diff_simple_minus_dcm"],
            ])

    simple_rf = np.array([row["rf_simple"] for row in rows], dtype=np.int64)
    dcm_rf = np.array([row["rf_dcm"] for row in rows], dtype=np.int64)
    diff_rf = simple_rf - dcm_rf
    test = wilcoxon(simple_rf, dcm_rf, zero_method="zsplit", method="auto")
    diff_sd = float(np.std(diff_rf, ddof=1)) if len(diff_rf) > 1 else float("nan")
    cohen_d = float(np.mean(diff_rf) / diff_sd) if diff_sd else None
    rng = np.random.default_rng(20261022)
    boot_mean_diff = np.mean(rng.choice(diff_rf, size=(10000, len(diff_rf)), replace=True), axis=1)
    ci_rf = np.percentile(boot_mean_diff, [2.5, 97.5])

    runtime = {}
    for mode in ("simple", "dcm"):
        path = BENCH / f"runtime_{mode}.json"
        runtime[mode] = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []

    archive_rf_all = np.array([row["archived_rf"] for row in rows], dtype=np.int64)
    dcm_minus_archive = dcm_rf - archive_rf_all

    archived_tree = read_newick(str(DATA / "seed1000_clean_fusang.nwk"))
    true1000 = read_newick(str(DATA / "seed1000_clean_true.nwk"))
    simple1000 = read_newick(str(BENCH / "seed1000_clean_simple.nwk"))
    dcm1000 = read_newick(str(BENCH / "seed1000_clean_dcm.nwk"))
    flag_only1000 = read_newick(str(BENCH / "seed1000_clean_simple_flag_only.nwk"))
    archived_rf = rf_distance(true1000, archived_tree)
    simple1000_rf = rf_distance(true1000, simple1000)
    dcm1000_rf = rf_distance(true1000, dcm1000)
    archived_to_simple_rf = rf_distance(archived_tree, simple1000)
    archived_to_dcm_rf = rf_distance(archived_tree, dcm1000)
    flag_only1000_rf = rf_distance(true1000, flag_only1000)
    flag_only_to_dcm_rf = rf_distance(flag_only1000, dcm1000)
    if archived_to_simple_rf == 0:
        archive_classification = "simple"
    elif archived_to_dcm_rf == 0:
        archive_classification = "dcm"
    else:
        archive_classification = "not_reproduced_by_either_current_pipeline"

    summary = {
        "condition": "INDELible n=1000 clean",
        "seeds_requested": seeds,
        "seeds_complete": [row["seed"] for row in rows],
        "n_pairs": len(rows),
        "denominator_2n_minus_6": DENOM,
        "scoring": "nrf_standard.py root-independent unrooted RF",
        "pipeline_commands": {
            "simple_intended": "--tree_method nj --kmer_k 5 --kmer_gap gap2 --auto_group_method simple",
            "dcm": "--tree_method nj --kmer_k 5 --kmer_gap gap2 --auto_group_method nj_centroid",
            "cli_note": "At n=1000, --simple alone is overwritten by the nj_centroid branch and actually runs DCM; auto_group_method simple is required to execute the intended simplified pipeline without source modification."
        },
        "toolchain": {
            "python": sys.version,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "environment": "/opt/miniconda3/envs/fusang_bench in WSL Ubuntu-24.04"
        },
        "simple": {
            "mean_nrf": float(np.mean(simple_rf) / DENOM),
            "sd_nrf_sample": float(np.std(simple_rf / DENOM, ddof=1)),
            "mean_rf": float(np.mean(simple_rf)),
            "sd_rf_sample": float(np.std(simple_rf, ddof=1)),
        },
        "dcm": {
            "mean_nrf": float(np.mean(dcm_rf) / DENOM),
            "sd_nrf_sample": float(np.std(dcm_rf / DENOM, ddof=1)),
            "mean_rf": float(np.mean(dcm_rf)),
            "sd_rf_sample": float(np.std(dcm_rf, ddof=1)),
        },
        "paired_simple_minus_dcm": {
            "mean_nrf_difference": float(np.mean(diff_rf) / DENOM),
            "mean_rf_difference": float(np.mean(diff_rf)),
            "wilcoxon_statistic": float(test.statistic),
            "wilcoxon_p_two_sided": float(test.pvalue),
            "wilcoxon_input": "integer RF counts",
            "wilcoxon_zero_method": "zsplit",
            "wilcoxon_method": "auto",
            "paired_cohens_d": cohen_d,
            "dcm_wins": int(np.sum(diff_rf > 0)),
            "simple_wins": int(np.sum(diff_rf < 0)),
            "ties": int(np.sum(diff_rf == 0)),
            "bootstrap_resamples": 10000,
            "bootstrap_seed": 20261022,
            "bootstrap_mean_difference_95pct_ci_nrf": [float(ci_rf[0] / DENOM), float(ci_rf[1] / DENOM)],
            "bootstrap_mean_difference_95pct_ci_rf": [float(ci_rf[0]), float(ci_rf[1])],
        },
        "archive_provenance_seed1000": {
            "archived_rf": archived_rf,
            "archived_nrf": archived_rf / DENOM,
            "rerun_simple_rf": simple1000_rf,
            "rerun_simple_nrf": simple1000_rf / DENOM,
            "rerun_dcm_rf": dcm1000_rf,
            "rerun_dcm_nrf": dcm1000_rf / DENOM,
            "archived_vs_rerun_simple_rf": archived_to_simple_rf,
            "archived_vs_rerun_dcm_rf": archived_to_dcm_rf,
            "archived_matches_simple_topology": archived_to_simple_rf == 0,
            "archived_matches_dcm_topology": archived_to_dcm_rf == 0,
            "classification": archive_classification,
            "provenance_conclusion": "dcm_by_run_bench_indelible_invocation_and_file_timestamp_chain_but_not_exactly_topology_reproduced",
            "provenance_evidence": "run_bench_indelible.py adds --auto_group_method nj_centroid for n>500; seed1029 tree timestamp 2026-10-22 00:36:33 and benchmark CSV timestamp 00:36:34",
            "simple_flag_only_rf": flag_only1000_rf,
            "simple_flag_only_nrf": flag_only1000_rf / DENOM,
            "simple_flag_only_vs_explicit_dcm_rf": flag_only_to_dcm_rf,
            "simple_flag_only_actually_matches_dcm_topology": flag_only_to_dcm_rf == 0,
        },
        "per_seed_integer_rf": [
            {"seed": row["seed"], "rf_simple": row["rf_simple"], "rf_dcm": row["rf_dcm"],
             "rf_diff_simple_minus_dcm": row["rf_diff_simple_minus_dcm"]}
            for row in rows
        ],
        "split_count_qa": [
            {"seed": row["seed"], "true": row["splits_true"], "simple": row["splits_simple"], "dcm": row["splits_dcm"]}
            for row in rows
        ],
        "archive_vs_rerun_dcm_qa": [
            {"seed": row["seed"], "archived_rf": row["archived_rf"], "rerun_dcm_rf": row["rf_dcm"],
             "archived_vs_rerun_dcm_rf": row["archived_vs_rerun_dcm_rf"]}
            for row in rows
        ],
        "archive_representativeness": {
            "archived": {
                "mean_nrf": float(np.mean(archive_rf_all) / DENOM),
                "sd_nrf_sample": float(np.std(archive_rf_all / DENOM, ddof=1)),
                "mean_rf": float(np.mean(archive_rf_all)),
            },
            "dcm_rerun_minus_archived": {
                "mean_nrf_difference": float(np.mean(dcm_minus_archive) / DENOM),
                "mean_rf_difference": float(np.mean(dcm_minus_archive)),
                "per_seed_rf_differences": [int(x) for x in dcm_minus_archive],
                "max_abs_rf_difference": int(np.max(np.abs(dcm_minus_archive))),
            },
            "conclusion": "Topology of archived trees is not exactly reproducible under the current code, but per-seed accuracy (RF to true tree) agrees closely, so Table 1 n=1000 values are representative of current-code behaviour.",
        },
        "runtime_records": runtime,
    }
    output_json = ROOT / "table_threshold_n1000_summary.json"
    output_json.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", choices=["simple", "dcm"])
    parser.add_argument("--summarize", action="store_true")
    parser.add_argument("--seeds", default="1000-1009")
    args = parser.parse_args()
    seeds = parse_seeds(args.seeds)
    if args.run:
        raise SystemExit(run_mode(args.run, seeds))
    if args.summarize:
        raise SystemExit(summarize(seeds))
    parser.error("specify --run or --summarize")


if __name__ == "__main__":
    main()
