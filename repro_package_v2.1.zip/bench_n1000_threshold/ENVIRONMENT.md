# ENVIRONMENT — n=1000 DCM vs simplified-pipeline threshold re-measurement

All runs behind `table_threshold_n1000_nrfstandard.csv` and
`table_threshold_n1000_summary.json` were executed in the environment below.
Using a different Python/NumPy/Numba version may change results (the k-mer
distance and NJ/NNI code paths are version-sensitive; see the
non-reproducibility evidence at the bottom).

## Compute environment

- Host OS: Windows 11 Pro, WSL2
- WSL distribution: **Ubuntu-24.04** (not the default distro; must be selected
  explicitly, e.g. `wsl -d Ubuntu-24.04`)
- Conda env: **fusang_bench** at `/opt/miniconda3/envs/fusang_bench`
- Python 3.11.17 / NumPy 2.4.6 / SciPy 1.17.1 / Numba 0.68.0
- Working directory (inside WSL): `/mnt/d/系统发育树项目/Fusang/Fusang-main`

## Code versions

- `fusang_v2.py` at commit **fe401bf5e46cf85716c647a2952cc7aa9c3c42cf**
  ("Manuscript: add n=1000 topological non-reproducibility disclosure...") —
  this is the version used for ALL benchmark trees in
  `bench_n1000_threshold/seed10{00..09}_clean_{simple,dcm}.nwk` and for all
  forensic (provenance) reruns.
- CLI fix commit **4e6bf02b76172e1f5fe8eef91712ba285e611de7** ("fix(CLI):
  --simple/--no-simple now take precedence over the n>500 auto-switch") was
  made AFTER the benchmark. It only restores the documented semantics of the
  explicit flags and does not change any default behaviour (verified: no-flag
  n=1000 run under the fixed code reproduces the pre-fix DCM tree with RF=0;
  `--simple` n=1000 reproduces the `auto_group_method simple` tree with RF=0;
  no-flag n=200 still prints "using simplified pipeline"). Verification logs:
  `bench_n1000_threshold/verify_{default_n1000,default_n200,simple_n1000}.log`.
- Misleading comment in `run_scalability_test_fixed.py` ("--simple works up
  to n=5000") corrected in commit **<SCALABILITY_COMMENT_COMMIT>** — the flag
  was a silent no-op for n>500 before the CLI fix (historical 500<n≤5000
  scalability timings were DCM runs).
- Scoring: `nrf_standard.py` (root-independent unrooted RF, denominator
  2(n−3)=1994 for n=1000). Never `calc_nrf_simple.py`.

## The four command lines

Common prefix (all run inside the WSL env above, from the repo root):

```
/opt/miniconda3/envs/fusang_bench/bin/python fusang_v2.py \
  --input indelible_n1000_clean/seed{S}_clean.fasta \
  --output <OUT> --tree_method nj --kmer_k 5 --kmer_gap gap2 <EXTRA>
```

1. **Archived trees (provenance)** — produced by the benchmark driver, not by
   hand. `run_bench_indelible.py` (`--n 1000 --tag clean --seeds 1000-1029
   --data_dir indelible_n1000_clean --out ...`) invokes, for n>500
   (`run_bench_indelible.py:84-90`):
   `<EXTRA> = --auto_group_method nj_centroid`
2. **`--simple` flag only**: `<EXTRA> = --simple`
   Pre-fix (commit fe401bf) this is silently overridden to DCM: the log prints
   "auto_group_method=nj_centroid: using DCM pipeline (n=1000 > 500)" and the
   tree is topologically identical to invocation 1 (RF=0 between them).
   Post-fix (commit 4e6bf02) it genuinely runs the simplified pipeline.
3. **True simplified pipeline** (the only reliable way pre-fix):
   `<EXTRA> = --auto_group_method simple`
4. **Explicit DCM**: `<EXTRA> = --auto_group_method nj_centroid`
   (identical result to 1 and to pre-fix 2).

Batch driver for the 10-seed comparison:
`bench_n1000_threshold/run_threshold_benchmark.py` (same interpreter; per-seed
logs `bench_n1000_threshold/seed{S}_clean_{MODE}.log`, runtimes in
`runtime_{simple,dcm}.json`).

## Non-reproducibility of archived topologies (quantified, denominator 1994)

- Seed 1000: archived RF to true tree 562 (nRF 0.281846, matches
  `table1_nrfstandard/n1000_clean_nrfstandard.csv` exactly); current-code DCM
  rerun 574 (nRF 0.287864), archived-vs-rerun RF = 104; current-code
  true-simplified rerun 538 (nRF 0.269809), archived-vs-rerun RF = 184.
- 10-seed archived-vs-DCM-rerun RF: 104, 4, 2, 14, 10, 18, 30, 178, 6, 22
  (median 14) — exact topologies are NOT reproducible under the current code
  and pinned environment.

## Accuracy-level reproducibility (why Table 1 n=1000 values still stand)

- 10-seed means: archived nRF 0.2717±0.0173 vs DCM rerun 0.2726±0.0177;
  per-seed rerun−archived RF differences 12, −2, 0, 0, 2, 2, −4, 2, 4, 2
  (mean +1.8 RF = +0.0009 nRF, SD 0.0021, max |Δ| = 12); paired Wilcoxon on
  integer RF (zsplit) **p = 0.227** — statistically indistinguishable.
- Interpretation: the run-to-run variation of the DCM pipeline lands in a
  topological neighbourhood whose distance to the true tree is essentially
  equivalent to that of the archived trees, so topological non-reproducibility
  does not translate into an accuracy-level discrepancy.

## Pipeline comparison headline numbers (10 clean seeds, 1000–1009)

- Simplified (auto_group_method simple): nRF 0.2617±0.0156 (RF 521.8±31.2)
- DCM (auto_group_method nj_centroid): nRF 0.2726±0.0177 (RF 543.6±35.3)
- Paired (simple−DCM, integer RF, zsplit): mean −0.010933 nRF, Wilcoxon
  p = 0.00195, paired Cohen's d = −1.45, wins 10/0/0, bootstrap (10,000
  resamples) 95% CI of mean difference [−0.0156, −0.0068]
- Runtime: simplified mean 502 s/seed (371–695) vs DCM mean 162 s/seed (44–225)
  → DCM's advantage is speed, not accuracy, at n=1000.

## Additional cross-check (Windows Python, NOT used for headline numbers)

`C:/Users/admin/AppData/Local/Python/bin/python.exe` (Python 3.14.2, NumPy
2.4.1, SciPy 1.17.1, Numba 0.65.1) reproduced the same three-way pattern on
seed 1000 (archived 562 / DCM 574 / simple 538); trees kept as
`seed1000_clean_*_windows_py314.nwk` for provenance.
