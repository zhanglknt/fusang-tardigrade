# 独立验证记录：标准无根 RF 口径（realdata-rf2）

日期：2026-10-22。范围：真实数据四基准 nRF 重算 + INDELible n=200 indel 130-seed 竞品表全量第三方复核 + nrf_standard.py leaf-at-root 修复验证。
执行人：realdata-rf2。环境：`C:\Python314\python.exe`，Python 3.14 / **dendropy 5.0.8** / **numpy 2.4.3** / **scipy 1.17.1**。

## 1. Oracle 设计与自检

`rf_audit.py`（仓库根）三路独立机制：

1. **DendroPy 5.0.8** `treecompare.symmetric_difference`（`rooting="force-unrooted"`、先剪枝到共享叶集、`TaxonNamespace` 同步）；
2. **自写显式 canonical split 提取器**（按"不含字典序最小叶的一侧"规范化；过滤 `1<|s|<n−1`；跳过叶节点子节点故不产生 pendant-edge 伪 split）；
3. **逐对断言**两路 RF 相等，并断言共享叶数 n。

**rerooting 不变性自检**：16S Fusang vs FastTree2 随机重根 20 次，nRF 恒为 0.371429（不变）——这是无根 RF 的定义性质。

## 2. 模拟数据竞品表全量复核（competitors-rf2 交付）

对象：`indelible_n200_indel/`，130 seeds（100–229）× 10 方法 × 双参考系（TRUE / FT2）= **2600 对**，全部从落盘树现算（未采样）。脚本：`verify_competitors_130seeds_dendropy.py`。

| 检查项 | 结果 |
|---|---|
| DendroPy vs 显式提取器一致性 | **2600/2600，0 处分歧** |
| 共享叶数 n | 2600/2600 = 200 |
| 真树 splits | **130/130 = 197**（完全解析） |
| 方法树 splits | **1300/1300 = 197** |
| FT2 参考树 splits | **19/130 = 197；111/130 polytomous，范围 187–196** |
| 与 `competitors_n200_indel_130seeds_stdrf.csv` 逐行对照 | **2600/2600 一致，max \|Δ\| = 4.98e−11**（浮点精度） |
| 与 `bench_n200_indel_130seeds_nrfstandard.csv`（fusang vs TRUE） | 130/130 一致（max 4.6e−07，6 位小数舍入） |

结论：FT2 参考系含大量 polytomy 是**唯一此前未被 oracle 盖章的部分**，现已确认 DendroPy 与团队实现对未解析参考树的处理完全一致；competitors-rf2 的新口径交付表现获四方一致（nrf_standard 修复版 = Bio.Phylo 独立实现 = DendroPy = 显式提取器）。

**口径提示**：FT2 帧仍按 2(n−3)=394 归一化（与稿件其他表一致），故相对分辨率感知分母 RF/(s₁+s₂) 系统性偏高；`dendropy_verify_130seeds.csv` 内含 `s_ref`，可现算备查值。

**统计检验提示**：本表逐 seed 的 `RF` 列为整数计数，是配对 Wilcoxon 的正确输入（见第 5 节第 1 条）；用浮点 nRF 直接检验会因舍入噪声破坏秩并列而使 p 值漂移。

## 3. nrf_standard.py leaf-at-root 修复验证

- **时间线**：今日 10:11 该文件被更新为 `return {s for s in result if 1 < len(s) < len(all_leaves) - 1}`（修复版 md5 `3213ff58355629d41d6884ffbe1e9d7a`）；我独立复现过该缺陷（构造同拓扑、不同根位置的两棵 Newick，旧版 RF 虚增）。
- **真实数据影响面扫描**（214 个树文件）：**95/214 棵是 leaf-at-root 写法**（IQ-TREE 两棵、SwissTree 全部 66 棵 NJ 树等），命中面远高于模拟数据；若用旧版跑真实数据会中招。
- **修复版一致性**：99 个真实数据树对（16S 7、SwissTree 66、BAliBASE 20、AFproject 6）与 DendroPy oracle **99/99 一致，零分歧**。
- **splits==n−3 自检**：214 棵树中仅 6 棵不等，全部是**真实 polytomy**（SwissTree 参考树 ST001/ST002/ST003/ST007/ST012）+ 1 棵混有 FastTree stderr 前缀行的废弃树，均与 bug 无关。
- **残留限制（真实数据常见）**：① tokenizer 不支持带空格的引号标签（`'Candidatus Neoarthromitus'`），16S 分类学参考树解析失败；② `nrf()` 不剪枝共享叶集，分母取 tree1 叶数。本批数据叶集一致，无数值影响。

## 4. 真实数据四基准（本人交付）

重跑管线的树一致性已用**原** `calc_nrf_simple.calc_nrf` 复算验证（SwissTree **66/66**、BAliBASE **20/20** 逐位复现原值）→ 新旧差值纯系度量口径切换，无管线漂移。

| 基准 | 原实现 | 是否标准无根 RF | 数值 |
|---|---|---|---|
| 16S rRNA（Table 9） | `real_16S_monophyly.py` | **是** | 不变（0.4143/0.3429/0.3714；单系性 3/7、10/14 复验一致） |
| SwissTree（Table 10） | `calc_nrf_simple` | 否 → 已重算 | Fusang k5g2 0.329、k4g1 0.354；Co-phylog h5 0.786、h11 0.727；k-mer>Co-phylog 2.1–2.4×，p≤0.002；**spaced 优势主张失效**（p=0.0078→0.797） |
| BAliBASE（S7/S6C） | `calc_nrf_simple` | 否 → 已重算 | median 0.982（旧 0.445），<0.5 比例 15%（旧 65%）；**"competitive" 结论反转** |
| AFproject（Table 12/S16/S17） | ETE3 compare unrooted | **是** | 全部复现（fish multik 0.0455、ecoli cosine 0.50、13 基因座 52/52） |

## 5. 遗留事项（需团队决策）

1. **p 值口径：根因已查明并修复（competitors-rf2 commit 7f7edfe，本人独立复算确认）**。
   - **根因**：nRF 落在 k/394 的整数网格上，但把浮点 nRF 直接喂给 Wilcoxon 时，名义相同的差值（如 −2/394）因各自舍入误差产生 ~1e−17 差异，本应并列的 |d| 不再并列，中秩分配被破坏。实测（cosine_k7 vs TRUE）：整数差值 113 个非零 |d| 应落在 **9 个并列组**，原始浮点只剩 17 组。
   - **影响**：p 值随舍入程度漂移（同一份数据：整数 RF 0.00391 / round 10 位 0.003271 / round 12 位 0.003929 / 原始浮点 0.004658）。我先前报的 0.00327 与他先前报的 0.00466 **都是噪声伪影**；方向与显著性等级未翻转，但机制上存在方向性风险。
   - **规范做法（已一致同意）**：Wilcoxon 在**整数 RF 计数**（nRF×2(n−3)）上执行 `zero_method='zsplit'`；均值/SD/Cohen's d/wins 不受影响。
   - **本人独立确认**：用我 CSV 中的整数 RF 列（DendroPy 导出，与他的管线无关）复算，逐位复现其修正值 —— TRUE 系 cosine_k7 **0.003910**、multik **0.007657**、cosine_k5 4.96e−05、cosine_k9 0.3756、fusang_nj 0.3402、Co-phylog/kmacs ≈4.3e−23；FT2 系 cosine_k7 **4.503e−06**、multik **1.244e−04**、cosine_k5 0.5504、cosine_k9 0.7487、fusang_nj 0.03469。
   - **稿件表注建议**：`scipy.stats.wilcoxon(paired, two-sided, zero_method='zsplit')` on exact integer RF counts（scipy 1.17.1）。逐 seed nRF 数值表不受影响，第 2 节 2600/2600 对照依然成立。
   - **本人交付的 SwissTree p 值已同步切换到整数 RF 重算**（`real_data_rf_recomputed.md` + `swisstree_rf_recomputed/swisstree_paired_tests_intRF.csv` + summary json 的 `stats_intRF`）：共核验 **8 组**配对比较，**无任何一组跨越 0.05 / 0.01 阈值**，结论全部不变。Fusang vs Co-phylog 四条 p 值**不变**（0.00195 / 0.000977）；spaced k4g1 vs contiguous k4 由 0.766 → **0.797**、k5g2 vs k5 由 0.094 → **0.156**（两者均不显著，"spaced 优势消失"结论不受影响）。**注意漂移幅度本身可相当大**（k4g1 vs contiguous k5：0.607 → 0.373；k5g2 vs contiguous k4：0.0625 → 0.0625），即"网格粗则漂移小"的判断并不保险。
   - **16S / BAliBASE / AFproject 无需重算**：16S 的 Table 9 p 值来自对 patristic 距离的 10,000 次置换检验（连续量，不在 k/2(n−3) 网格上），本基准不存在基于 RF 的配对 Wilcoxon；BAliBASE 与 AFproject 我仅给出描述统计（median、<0.5 比例、per-dataset 数值），未做配对检验。
2. **文件来源混淆风险**：`indelible_n200_indel/` 现并存 4 组同名近似竞品表（…130seeds.csv / …fusangbench.csv+json / …stdrf.csv+json / bench…nrfstandard.csv）。新口径**唯一取数来源应为 `competitors_n200_indel_130seeds_stdrf.csv` / `_stdrf_summary.json`**；fusangbench 那组按"不覆盖旧表"要求保留旧值，不得用于稿件取数。
3. BAliBASE 工作区 `RV11/BB11002.{xml,msf,tfa}` 已损坏，已从 `balibase/BAliBASE_R1-5.tar.gz` 恢复后重跑（其余 19 family 与 tar 包逐字节一致）。

## 6. 产出文件

- `rf_audit.py`（oracle）、`verify_competitors_130seeds_dendropy.py`（全量复核脚本）
- `real_data_rf_recomputed.md`（真实数据总报告）、`real_data/real_16S_rf_standard.csv`
- `swisstree_rf_recomputed/`（CSV+JSON+66 树）、`balibase_rf_recomputed/`（CSV+JSON+40 树）、`afproject_rf_recomputed/`（CSV+JSON）
- `indelible_n200_indel/dendropy_verify_130seeds.csv`（2600 行底表）、`dendropy_verify_130seeds.json`、`dendropy_means_stdrf.json`
- `recompute_{16s,swisstree,balibase,afproject}_rf.py`
