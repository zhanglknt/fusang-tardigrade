#!/usr/bin/env python3
"""Generate FASTA with real phylogenetic signal + indels.
Generates a random tree, then simulates sequences along branches
using substitution + insertion/deletion (indel) events.
Sequences end up with variable lengths — realistic for alignment-free benchmarking.

Indel model: POW 1.5 power-law on indel lengths, Poisson on count per branch.

Usage: python gen_test_data_indel.py <n> <length> <sub_rate> <indel_rate> <seed>
Output: test_indel_n{N}.fasta + test_indel_n{N}_true.nwk
"""

import sys
import random
import math
import hashlib
import json
import csv
import os
from datetime import datetime

BASES = ['A', 'T', 'C', 'G']

# === Data Provenance Tracking ===
PROVENANCE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'DATA_PROVENANCE.csv')

def _provenance_headers():
    return ['dataset_name','data_type','source_url','local_path','sha256',
            'n_seqs','seq_length_mean','generation_params','created_date',
            'fusang_version','valid_seeds','missing_seeds','notes']

def log_data_provenance(dataset_name, fasta_path, nwk_path, n_seqs, params,
                         fusang_version='v2.1', notes=''):
    """Compute SHA256 and append provenance row to DATA_PROVENANCE.csv."""
    sha_fasta = hashlib.sha256(open(fasta_path, 'rb').read()).hexdigest()
    sha_nwk = hashlib.sha256(open(nwk_path, 'rb').read()).hexdigest()

    # Compute mean sequence length from FASTA
    seqs = []
    header = None
    with open(fasta_path) as f:
        for line in f:
            line = line.strip()
            if line.startswith('>'):
                if header is not None:
                    seqs.append(len(header))
                header = ''
            else:
                header += line
        if header is not None:
            seqs.append(len(header))
    mean_len = sum(seqs) / len(seqs) if seqs else 0

    row = {
        'dataset_name': dataset_name,
        'data_type': 'simulated_jc69',
        'source_url': 'N/A (simulated)',
        'local_path': os.path.basename(fasta_path),
        'sha256': sha_fasta,
        'n_seqs': n_seqs,
        'seq_length_mean': round(mean_len, 1),
        'generation_params': json.dumps(params),
        'created_date': datetime.now().strftime('%Y-%m-%d'),
        'fusang_version': fusang_version,
        'valid_seeds': '',
        'missing_seeds': '',
        'notes': notes
    }

    file_exists = os.path.exists(PROVENANCE_FILE)
    with open(PROVENANCE_FILE, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=_provenance_headers())
        if not file_exists or os.path.getsize(PROVENANCE_FILE) == 0:
            writer.writeheader()
        writer.writerow(row)

    print(f"  Provenance: SHA256(fasta)={sha_fasta[:16]}... logged to DATA_PROVENANCE.csv")
    return sha_fasta


def generate_tree_newick(n, seed=42):
    """Generate random coalescent-like tree in NEWICK format."""
    random.seed(seed)
    tips = [f"seq{i}" for i in range(n)]
    active = [(tips[i], tips[i]) for i in range(n)]
    ic = 0
    while len(active) > 1:
        idxs = sorted(random.sample(range(len(active)), 2), reverse=True)
        j, i = idxs[0], idxs[1]
        left, right = active[i], active[j]
        inode = f"I{ic}"
        ic += 1
        node_str = f"({left[0]}:0.1000,{right[0]}:0.1000)"
        active.pop(j)
        active.pop(i)
        active.append((node_str, inode))
    return active[0][0] + ";"


def geometric_length(mean=3.0, max_len=50):
    """Sample a geometrically-distributed length (power-law like POW 1.5)."""
    p = 1.0 / mean
    while True:
        k = int(math.log(1.0 - random.random()) / math.log(1.0 - p)) + 1
        if k <= max_len:
            return k


def apply_indels(seq, n_indels, max_len=50):
    """Apply n_indels insertion/deletion events in-place.
    Returns mutated sequence (list of chars).
    
    Each event: 50% insert, 50% delete.
    Insert: random position, geometric length, random bases.
    Delete: random position, geometric length (capped at remaining seq).
    """
    seq = seq[:]  # copy
    for _ in range(n_indels):
        if not seq:
            # Can't delete from empty; force insert
            is_insert = True
        else:
            is_insert = random.random() < 0.5
        
        if is_insert:
            pos = random.randint(0, len(seq))
            length = geometric_length(mean=3.0, max_len=max_len)
            insert_bases = [random.choice(BASES) for _ in range(length)]
            seq[pos:pos] = insert_bases
        else:
            length = geometric_length(mean=3.0, max_len=max_len)
            if length >= len(seq):
                length = max(1, len(seq) - 1)
            pos = random.randint(0, len(seq) - length)
            del seq[pos:pos + length]
    return seq


def apply_substitutions(seq, sub_rate, branch_length):
    """Apply Poisson(sub_rate * bl * len) substitutions."""
    seq = seq[:]
    n_mut = max(0, int(random.gauss(
        sub_rate * branch_length * len(seq),
        math.sqrt(sub_rate * branch_length * len(seq))
    )))
    if n_mut <= 0:
        return seq
    for _ in range(n_mut):
        pos = random.randint(0, len(seq) - 1)
        cur = seq[pos]
        choices = [b for b in BASES if b != cur]
        seq[pos] = random.choice(choices)
    return seq


def simulate_sequences_indel(true_nwk_path, fasta_path, length=1000,
                              sub_rate=0.05, indel_rate=0.01, seed=123):
    """Simulate sequences along the true tree with substitutions + indels."""
    from io import StringIO
    from Bio import Phylo

    random.seed(seed)

    with open(true_nwk_path) as f:
        nwk = f.read().strip()

    tree = Phylo.read(StringIO(nwk), "newick")

    # Root gets random sequence of target length
    root_seq = [random.choice(BASES) for _ in range(length)]
    seqs = {tree.root: root_seq}

    def dfs(node):
        for child in node.clades:
            parent_seq = seqs[node]
            bl = child.branch_length if child.branch_length else 0.1
            
            child_seq = parent_seq[:]
            
            # 1. Apply indels first (change sequence length)
            n_indels = max(0, int(random.gauss(
                indel_rate * bl * len(child_seq),
                math.sqrt(indel_rate * bl * len(child_seq))
            )))
            if n_indels > 0:
                child_seq = apply_indels(child_seq, n_indels)
            
            # 2. Apply substitutions on the indel-modified sequence
            child_seq = apply_substitutions(child_seq, sub_rate, bl)
            
            seqs[child] = child_seq
            dfs(child)

    dfs(tree.root)

    # Write unaligned FASTA
    terminals = {leaf.name: leaf for leaf in tree.get_terminals()}
    with open(fasta_path, 'w') as f:
        for name in sorted(terminals.keys()):
            leaf = terminals[name]
            seq_str = "".join(seqs[leaf])
            f.write(f">{name}\n")
            for k in range(0, len(seq_str), 80):
                f.write(seq_str[k:k+80] + "\n")

    lengths = [len(seqs[leaf]) for leaf in terminals.values()]
    print(f"  Generated {fasta_path}: {len(terminals)} seqs, "
          f"length range={min(lengths)}-{max(lengths)}, "
          f"mean={sum(lengths)/len(lengths):.0f}")
    
    return seqs


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    length = int(sys.argv[2]) if len(sys.argv) > 2 else 500
    sub_rate = float(sys.argv[3]) if len(sys.argv) > 3 else 0.05
    indel_rate = float(sys.argv[4]) if len(sys.argv) > 4 else 0.01
    seed = int(sys.argv[5]) if len(sys.argv) > 5 else 42

    base = f"test_indel_n{n}"
    fasta = f"{base}.fasta"
    true_nwk = f"{base}_true.nwk"

    print(f"Generating indel test data: n={n}, L={length}, "
          f"sub_rate={sub_rate}, indel_rate={indel_rate}, seed={seed}")

    nwk_str = generate_tree_newick(n, seed=seed)
    with open(true_nwk, 'w') as f:
        f.write(nwk_str)
    print(f"  True tree: {true_nwk}")

    simulate_sequences_indel(true_nwk, fasta, length=length,
                              sub_rate=sub_rate, indel_rate=indel_rate,
                              seed=seed + 1)

    print(f"Done: {fasta}, {true_nwk}")

    # Log data provenance
    params = {'n': n, 'L': length, 'sub_rate': sub_rate, 'indel_rate': indel_rate,
              'model': 'JC69', 'seed': seed}
    log_data_provenance(
        dataset_name=f'n{n}_sub{sub_rate}_indel{indel_rate}_seed{seed}',
        fasta_path=fasta,
        nwk_path=true_nwk,
        n_seqs=n,
        params=params
    )
